﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab20_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtInputFirstA_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (textBox.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnFindIntersection.Focus();
                }
                return;
            }
            e.Handled = true;


        }

        private void btnFindIntersection_Click(object sender, EventArgs e)
        {
            try
            {
                double a1 = Convert.ToDouble(txtInputFirstA.Text);
                double b1 = Convert.ToDouble(txtInputFirstB.Text);
                double c1 = Convert.ToDouble(txtInputFirstC.Text);
                double a2 = Convert.ToDouble(txtInputSecondA.Text);
                double b2 = Convert.ToDouble(txtInputSecondB.Text);
                double c2 = Convert.ToDouble(txtInputSecondC.Text);
                Line l1 = new Line(a1, b1, c1);
                Line l2 = new Line(a2, b2, c2);
                var (x, y) = LineIntersection.FindIntersection(l1, l2);
                lblResult.Text = $"Точка перетину прямих ({x}, {y})";
                lblResult.ForeColor = System.Drawing.Color.Black;
            }
            catch(InvalidOperationException ex)
            {
                lblResult.Text = ex.Message;
                lblResult.ForeColor = System.Drawing.Color.Red;
            }
            catch(ArgumentException ex)
            {
                lblResult.Text = ex.Message;
                lblResult.ForeColor = System.Drawing.Color.Red;
            }
            catch
            {
                if(txtInputFirstA.Text.Length == 0)
                {
                    txtInputFirstA.Focus();
                }
                else if (txtInputFirstB.Text.Length == 0)
                {
                    txtInputFirstB.Focus();
                }
                else if (txtInputFirstC.Text.Length == 0)
                {
                    txtInputFirstC.Focus();
                }
                else if (txtInputSecondA.Text.Length == 0)
                {
                    txtInputSecondA.Focus();
                }
                else if (txtInputSecondB.Text.Length == 0)
                {
                    txtInputSecondB.Focus();
                }
                else
                {
                    txtInputSecondC.Focus();
                }
            }
        }
    }
}
