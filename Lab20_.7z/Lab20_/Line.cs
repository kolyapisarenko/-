﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab20_
{
    struct Line
    {
        public double A, B, C;
        public Line(double a, double b, double c)
        {
            if (a == 0 && b == 0)
            {
                throw new ArgumentException("A і B не можуть одночасно бути рівними нулю");
            }
            A = a;
            B = b;
            C = c;
        }
    }

    class LineIntersection
    {
        public static (double, double) FindIntersection(Line l1, Line l2)
        {
            double d = l1.A * l2.B - l2.A * l1.B;

            if (d == 0)
            {
                throw new InvalidOperationException("Прямі паралельні або співпадають");
            }

            double x = (l1.B * l2.C - l2.B * l1.C) / d;
            double y = (l2.A * l1.C - l1.A * l2.C) / d;

            return (x, y);
        }
    }
}
