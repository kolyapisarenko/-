﻿using System;
using System.Drawing;
using System.Windows.Forms;
using OOP_Lab21.Resources;

namespace OOP_Lab21
{
    public partial class FindForm : Form
    {
        public FindForm()
        {
            InitializeComponent();
            ApplyLocalization();
        }

        public void ApplyLocalization()
        {
            this.Text = Resources.Resource.FindForm_Title;
            //lblFind.Text = Resources.Resource.FindForm_Label;
            cbMatchCase.Text = Resources.Resource.FindForm_MatchCase;
            cbMatchWhole.Text = Resources.Resource.FindForm_MatchWhole;
            btnOK.Text = Resources.Resource.FindForm_OK;
            btnCancel.Text = Resources.Resource.FindForm_Cancel;
        }

        public RichTextBoxFinds FindCondition
        {
            get
            {
                if (cbMatchCase.Checked && cbMatchWhole.Checked)
                    return RichTextBoxFinds.MatchCase | RichTextBoxFinds.WholeWord;
                if (cbMatchCase.Checked)
                    return RichTextBoxFinds.MatchCase;
                if (cbMatchWhole.Checked)
                    return RichTextBoxFinds.WholeWord;
                return RichTextBoxFinds.None;
            }
        }

        public string FindText
        {
            get { return txtFind.Text; }
            set { txtFind.Text = value; }
        }
    }
}