﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using OOP_Lab21.Resources;

namespace OOP_Lab21
{
    public partial class blank : Form
    {
        // Налаштування підсвічування синтаксису
        private readonly Color keywordColor = Color.Blue;
        private readonly Color commentColor = Color.Green;
        private readonly Color stringColor = Color.Red;
        private readonly string[] keywords = {
            "auto", "break", "case", "char", "const", "continue", "default",
            "do", "double", "else", "enum", "extern", "float", "for", "goto",
            "if", "int", "long", "register", "return", "short", "signed",
            "sizeof", "static", "struct", "switch", "typedef", "union",
            "unsigned", "void", "volatile", "while"
        };

        private System.Windows.Forms.Timer highlightTimer;
        private bool isHighlighting = false;
        public string DocName = "";
        public bool isSaved = false;
        private string lastText = "";

        public blank()
        {
            InitializeComponent();
            InitializeSyntaxHighlight();
            ApplyLocalization();

            richTextBox1.SelectionChanged += RichTextBox1_SelectionChanged;
            sbTime.Text = DateTime.Now.ToLongTimeString();
            sbTime.ToolTipText = DateTime.Today.ToLongDateString();
        }

        private void InitializeSyntaxHighlight()
        {
            highlightTimer = new System.Windows.Forms.Timer { Interval = 500 };
            highlightTimer.Tick += (s, e) => {
                if (!isHighlighting && !richTextBox1.IsDisposed)
                {
                    SafeHighlightSyntax();
                }
            };

            richTextBox1.TextChanged += (s, e) => {
                if (!highlightTimer.Enabled)
                {
                    highlightTimer.Start();
                }
                UpdateStatusBar();
                isSaved = false;
            };
        }

        public void ApplyLocalization()
        {
            cmnuCut.Text = Resources.Resource.ContextMenu_Cut;
            cmnuCopy.Text = Resources.Resource.ContextMenu_Copy;
            cmnuPaste.Text = Resources.Resource.ContextMenu_Paste;
            cmnuDelete.Text = Resources.Resource.ContextMenu_Delete;
            cmnuSelectAll.Text = Resources.Resource.ContextMenu_SelectAll;
            UpdateStatusBar();
        }

        private void UpdateStatusBar()
        {
            sbAmount.Text = string.Format(Resources.Resource.StatusBar_Amount, richTextBox1.TextLength);
        }

        public void Cut() => richTextBox1.Cut();
        public void Copy() => richTextBox1.Copy();
        public void Paste() => richTextBox1.Paste();
        public void SelectAll() => richTextBox1.SelectAll();
        public void Delete() => richTextBox1.SelectedText = "";

        private void cmnuCut_Click(object sender, EventArgs e) => Cut();
        private void cmnuCopy_Click(object sender, EventArgs e) => Copy();
        private void cmnuPaste_Click(object sender, EventArgs e) => Paste();
        private void cmnuDelete_Click(object sender, EventArgs e) => Delete();
        private void cmnuSelectAll_Click(object sender, EventArgs e) => SelectAll();

        public void Open(string openFileName)
        {
            if (string.IsNullOrEmpty(openFileName)) return;

            try
            {
                highlightTimer.Stop();

                if (Path.GetExtension(openFileName).ToLower() == ".rtf")
                {
                    richTextBox1.LoadFile(openFileName, RichTextBoxStreamType.RichText);
                }
                else
                {
                    richTextBox1.Text = File.ReadAllText(openFileName);
                }

                DocName = openFileName;
                isSaved = true;
                lastText = richTextBox1.Text;
                SafeHighlightSyntax();
                UpdateStatusBar();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка відкриття файлу: {ex.Message}", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Save(string saveFileName)
        {
            if (string.IsNullOrEmpty(saveFileName)) return;

            try
            {
                if (Path.GetExtension(saveFileName).ToLower() == ".rtf")
                {
                    richTextBox1.SaveFile(saveFileName, RichTextBoxStreamType.RichText);
                }
                else
                {
                    File.WriteAllText(saveFileName, richTextBox1.Text);
                }
                DocName = saveFileName;
                isSaved = true;
                lastText = richTextBox1.Text;
                UpdateStatusBar();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження файлу: {ex.Message}", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void InsertImage()
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Images|*.bmp;*.jpg;*.jpeg;*.png";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    using (Image img = Image.FromFile(dlg.FileName))
                    {
                        Clipboard.SetImage(img);
                        richTextBox1.Paste();
                        sbAmount.Text = Resources.Resource.Status_ImageInserted;
                    }
                }
            }
        }

        public void SetImageAlignment(HorizontalAlignment alignment)
        {
            if (richTextBox1.SelectionLength > 0)
            {
                richTextBox1.SelectionAlignment = alignment;
            }
        }

        private void SafeHighlightSyntax()
        {
            if (richTextBox1.IsDisposed || isHighlighting || richTextBox1.Text == lastText)
                return;

            isHighlighting = true;

            try
            {
                int pos = richTextBox1.SelectionStart;
                int len = richTextBox1.SelectionLength;
                Point scrollPos = richTextBox1.GetPositionFromCharIndex(0);

                richTextBox1.SuspendLayout();

                // Зберігаємо поточний стиль тексту
                Font currentFont = richTextBox1.SelectionFont;
                Color currentColor = richTextBox1.SelectionColor;
                HorizontalAlignment currentAlignment = richTextBox1.SelectionAlignment;

                // Визначаємо змінені ділянки
                var changedRange = FindChangedRange();
                int start = changedRange.start;
                int end = changedRange.end;

                // Підсвічуємо тільки в межах зміненої ділянки
                if (start < end)
                {
                    // Підсвічуємо ключові слова
                    HighlightInRange(HighlightType.Keywords, start, end);

                    // Підсвічуємо коментарі
                    HighlightInRange(HighlightType.Comments, start, end);

                    // Підсвічуємо строки
                    HighlightInRange(HighlightType.Strings, start, end);
                }

                // Відновлюємо попередній стиль
                richTextBox1.Select(pos, len);
                richTextBox1.SelectionFont = currentFont;
                richTextBox1.SelectionColor = currentColor;
                richTextBox1.SelectionAlignment = currentAlignment;

                richTextBox1.ScrollToCaret();
                if (richTextBox1.GetPositionFromCharIndex(0) != scrollPos)
                {
                    richTextBox1.ScrollToCaret();
                }

                lastText = richTextBox1.Text;
                richTextBox1.ResumeLayout();
            }
            finally
            {
                isHighlighting = false;
            }
        }

        private (int start, int end) FindChangedRange()
        {
            string currentText = richTextBox1.Text;
            int minLength = Math.Min(currentText.Length, lastText.Length);

            int start = 0;
            while (start < minLength && currentText[start] == lastText[start])
            {
                start++;
            }

            int end = currentText.Length;
            int lastEnd = lastText.Length;
            while (end > start && lastEnd > start &&
                   end > 0 && lastEnd > 0 &&
                   currentText[end - 1] == lastText[lastEnd - 1])
            {
                end--;
                lastEnd--;
            }

            // Розширюємо область для гарантії правильного підсвічування
            start = Math.Max(0, start - 10);
            end = Math.Min(currentText.Length, end + 10);

            // Якщо текст повністю новий (наприклад, перший ввід)
            if (lastText.Length == 0)
            {
                start = 0;
                end = currentText.Length;
            }

            return (start, end);
        }

        private enum HighlightType { Keywords, Comments, Strings }

        private void HighlightInRange(HighlightType type, int start, int end)
        {
            string text = richTextBox1.Text;
            if (start >= text.Length) return;

            end = Math.Min(end, text.Length);

            switch (type)
            {
                case HighlightType.Keywords:
                    foreach (string keyword in keywords)
                    {
                        foreach (Match match in Regex.Matches(text, @"\b" + keyword + @"\b", RegexOptions.Multiline))
                        {
                            if (match.Index >= start && match.Index + match.Length <= end)
                            {
                                richTextBox1.Select(match.Index, match.Length);
                                if (richTextBox1.SelectionColor != keywordColor &&
                                    richTextBox1.SelectionFont != null &&
                                    !richTextBox1.SelectionFont.Bold &&
                                    !richTextBox1.SelectionFont.Italic)
                                {
                                    richTextBox1.SelectionColor = keywordColor;
                                }
                            }
                        }
                    }
                    break;

                case HighlightType.Comments:
                    foreach (Match match in Regex.Matches(text, @"//.*$", RegexOptions.Multiline))
                    {
                        if (match.Index >= start && match.Index + match.Length <= end)
                        {
                            richTextBox1.Select(match.Index, match.Length);
                            if (richTextBox1.SelectionColor != commentColor)
                            {
                                richTextBox1.SelectionColor = commentColor;
                            }
                        }
                    }

                    foreach (Match match in Regex.Matches(text, @"/\*.*?\*/", RegexOptions.Singleline))
                    {
                        if (match.Index >= start && match.Index + match.Length <= end)
                        {
                            richTextBox1.Select(match.Index, match.Length);
                            if (richTextBox1.SelectionColor != commentColor)
                            {
                                richTextBox1.SelectionColor = commentColor;
                            }
                        }
                    }
                    break;

                case HighlightType.Strings:
                    foreach (Match match in Regex.Matches(text, @"""[^""\\]*(\\.[^""\\]*)*""", RegexOptions.Multiline))
                    {
                        if (match.Index >= start && match.Index + match.Length <= end)
                        {
                            richTextBox1.Select(match.Index, match.Length);
                            if (richTextBox1.SelectionColor != stringColor)
                            {
                                richTextBox1.SelectionColor = stringColor;
                            }
                        }
                    }

                    foreach (Match match in Regex.Matches(text, @"'[^'\\]*(\\.[^'\\]*)*'", RegexOptions.Multiline))
                    {
                        if (match.Index >= start && match.Index + match.Length <= end)
                        {
                            richTextBox1.Select(match.Index, match.Length);
                            if (richTextBox1.SelectionColor != stringColor)
                            {
                                richTextBox1.SelectionColor = stringColor;
                            }
                        }
                    }
                    break;
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            UpdateStatusBar();
            isSaved = false;
        }

        private void RichTextBox1_SelectionChanged(object sender, EventArgs e)
        {
            if (this.MdiParent is Form1 mainForm)
            {
                mainForm.UpdateAlignmentMenu();
            }
        }

        private void blank_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (richTextBox1.Modified)
            {
                var result = MessageBox.Show(
                    string.Format(Resources.Resource.SaveChangesMessage, Path.GetFileName(DocName)),
                    Resources.Resource.SaveChangesTitle,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes) Save(DocName);
            }
        }

        public RichTextBox GetRichTextBox() => richTextBox1;
    }
}