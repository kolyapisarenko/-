﻿using System;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using OOP_Lab21.Resources;

namespace OOP_Lab21
{
    public partial class Form1 : Form
    {
        private string _currentLanguage = "";

        public Form1()
        {
            Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
            InitializeComponent();
            InitializeLanguageMenu();
            ApplyLocalization();
            mnuSave.Enabled = false;
        }

        private void InitializeLanguageMenu()
        {
            mnuLanguage.DropDownItems.Clear();
            AddLanguageMenuItem("English", "");
            AddLanguageMenuItem("Українська", "uk-UA");
            AddLanguageMenuItem("Français", "fr-FR");
            AddLanguageMenuItem("Deutsch", "de-DE");
            AddLanguageMenuItem("Italiano", "it-IT");
        }

        private void AddLanguageMenuItem(string languageName, string cultureCode)
        {
            var item = new ToolStripMenuItem(languageName);
            item.Tag = cultureCode;
            item.Click += (sender, e) => ChangeLanguage(cultureCode);
            mnuLanguage.DropDownItems.Add(item);
        }

        private void ChangeLanguage(string cultureCode)
        {
            _currentLanguage = cultureCode;
            Thread.CurrentThread.CurrentUICulture = string.IsNullOrEmpty(cultureCode)
                ? CultureInfo.InvariantCulture
                : new CultureInfo(cultureCode);

            ApplyLocalization();
            RefreshChildForms();
        }

        private void RefreshChildForms()
        {
            foreach (Form childForm in this.MdiChildren)
            {
                if (childForm is blank blankForm)
                {
                    blankForm.ApplyLocalization();
                }
                else if (childForm is FindForm findForm)
                {
                    findForm.ApplyLocalization();
                }
                else if (childForm is About aboutForm)
                {
                    aboutForm.ApplyLocalization();
                }
            }
        }

        private void ApplyLocalization()
        {
            this.Text = Resources.Resource.MainForm_Title;

            // File menu
            mnuFile.Text = Resources.Resource.MainForm_File;
            mnuNew.Text = Resources.Resource.MainForm_New;
            mnuOpen.Text = Resources.Resource.MainForm_Open;
            mnuSave.Text = Resources.Resource.MainForm_Save;
            mnuSaveAs.Text = Resources.Resource.MainForm_SaveAs;
            mnuExit.Text = Resources.Resource.MainForm_Exit;

            // Edit menu
            mnuEdit.Text = Resources.Resource.MainForm_Edit;
            mnuCut.Text = Resources.Resource.MainForm_Cut;
            mnuCopy.Text = Resources.Resource.MainForm_Copy;
            mnuPaste.Text = Resources.Resource.MainForm_Paste;
            mnuDelete.Text = Resources.Resource.MainForm_Delete;
            mnuFind.Text = Resources.Resource.MainForm_Find;
            mnuAll.Text = Resources.Resource.MainForm_SelectAll;

            // Format menu
            mnuFormat.Text = Resources.Resource.MainForm_Format;
            mnuAlignment.Text = Resources.Resource.MainForm_Alignment;
            mnuAlignLeft.Text = Resources.Resource.MainForm_AlignLeft;
            mnuAlignCenter.Text = Resources.Resource.MainForm_AlignCenter;
            mnuAlignRight.Text = Resources.Resource.MainForm_AlignRight;
            mnuFont.Text = Resources.Resource.MainForm_Font;
            mnuColor.Text = Resources.Resource.MainForm_Color;

            mnuImage.Text = Resources.Resource.Menu_Image;
            mnuInsert.Text = Resources.Resource.Menu_Image_Insert;
            mnuImageAlign.Text = Resources.Resource.Menu_Image_Alignment;
            mnuImageLeft.Text = Resources.Resource.Menu_Image_Left;
            mnuImageCenter.Text = Resources.Resource.Menu_Image_Center;
            mnuImageRight.Text = Resources.Resource.Menu_Image_Right;

            // Window menu
            mnuWindow.Text = Resources.Resource.MainForm_Window;
            mnuIcons.Text = Resources.Resource.MainForm_ArrangeIcons;
            mnuCascade.Text = Resources.Resource.MainForm_Cascade;
            mnuHorizontal.Text = Resources.Resource.MainForm_TileHorizontal;
            mnuVertical.Text = Resources.Resource.MainForm_TileVertical;

            // Language menu
            mnuLanguage.Text = Resources.Resource.Menu_Language;

            // Help menu
            mnuHelp.Text = Resources.Resource.MainForm_Help;
            mnuAbout.Text = Resources.Resource.MainForm_About;

            // Tooltips
            tbNew.ToolTipText = Resources.Resource.ToolBar_New;
            tbOpen.ToolTipText = Resources.Resource.ToolBar_Open;
            tbSave.ToolTipText = Resources.Resource.ToolBar_Save;
            tbCut.ToolTipText = Resources.Resource.ToolBar_Cut;
            tbCopy.ToolTipText = Resources.Resource.ToolBar_Copy;
            tbPaste.ToolTipText = Resources.Resource.ToolBar_Paste;
        }

        public void UpdateAlignmentMenu()
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                var alignment = frm.GetRichTextBox().SelectionAlignment;
                mnuAlignLeft.Checked = (alignment == HorizontalAlignment.Left);
                mnuAlignCenter.Checked = (alignment == HorizontalAlignment.Center);
                mnuAlignRight.Checked = (alignment == HorizontalAlignment.Right);
            }
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            UpdateAlignmentMenu();
        }

        private int openDocuments = 0;

        private void UpdateOpenWindowsList()
        {
            mnuIcons.DropDownItems.Clear();

            if (this.MdiChildren.Length == 0) return;

            int index = 1;
            foreach (Form child in this.MdiChildren)
            {
                ToolStripMenuItem childItem = new ToolStripMenuItem($"{index} {child.Text}");
                childItem.Click += (s, e) => child.Activate();
                mnuIcons.DropDownItems.Add(childItem);
                index++;
            }
        }

        private void mnuNew_Click(object sender, EventArgs e)
        {
            blank frm = new blank();
            frm.DocName = Resources.Resource.Blank_Untitled + " " + ++openDocuments;
            frm.Text = frm.DocName;
            frm.MdiParent = this;
            frm.Show();
            UpdateOpenWindowsList();
        }

        private void mnuIcons_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void mnuCascade_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void mnuHorizontal_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnuVertical_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void mnuCut_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            frm?.Cut();
        }

        private void mnuCopy_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            frm?.Copy();
        }

        private void mnuPaste_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            frm?.Paste();
        }

        private void mnuDelete_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            frm?.Delete();
        }

        private void mnuAll_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            frm?.SelectAll();
        }

        private void mnuOpen_Click(object sender, EventArgs e)
        {
            mnuSave.Enabled = true;
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|All Files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                blank frm = new blank();
                frm.Open(openFileDialog1.FileName);
                frm.MdiParent = this;
                frm.DocName = openFileDialog1.FileName;
                frm.Text = frm.DocName;
                frm.Show();
            }
        }

        private void mnuSave_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                frm.Save(frm.DocName);
                frm.isSaved = true;
            }
        }

        private void mnuSaveAs_Click(object sender, EventArgs e)
        {
            mnuSave.Enabled = true;
            saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|All Files (*.*)|*.*";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                blank frm = this.ActiveMdiChild as blank;
                if (frm != null)
                {
                    frm.Save(saveFileDialog1.FileName);
                    frm.MdiParent = this;
                    frm.DocName = saveFileDialog1.FileName;
                    frm.Text = frm.DocName;
                    frm.isSaved = true;
                }
            }
        }

        private void mnuFont_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                fontDialog1.ShowColor = true;
                fontDialog1.Font = frm.GetRichTextBox().SelectionFont;
                fontDialog1.Color = frm.GetRichTextBox().SelectionColor;
                if (fontDialog1.ShowDialog() == DialogResult.OK)
                {
                    frm.GetRichTextBox().SelectionFont = fontDialog1.Font;
                    frm.GetRichTextBox().SelectionColor = fontDialog1.Color;
                }
            }
        }

        private void mnuColor_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                colorDialog1.Color = frm.GetRichTextBox().SelectionColor;
                if (colorDialog1.ShowDialog() == DialogResult.OK)
                {
                    frm.GetRichTextBox().SelectionColor = colorDialog1.Color;
                }
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuFind_Click(object sender, EventArgs e)
        {
            FindForm frm = new FindForm();
            if (frm.ShowDialog(this) == DialogResult.OK && this.ActiveMdiChild is blank form)
            {
                int start = form.GetRichTextBox().SelectionStart;
                form.GetRichTextBox().Find(frm.FindText, start, frm.FindCondition);
            }
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            About frm = new About();
            frm.ShowDialog();
        }

        private void toolBarMain_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem?.Name)
            {
                case nameof(tbNew): mnuNew_Click(this, EventArgs.Empty); break;
                case nameof(tbOpen): mnuOpen_Click(this, EventArgs.Empty); break;
                case nameof(tbSave): mnuSave_Click(this, EventArgs.Empty); break;
                case nameof(tbCut): mnuCut_Click(this, EventArgs.Empty); break;
                case nameof(tbCopy): mnuCopy_Click(this, EventArgs.Empty); break;
                case nameof(tbPaste): mnuPaste_Click(this, EventArgs.Empty); break;
            }
        }

        private void mnuAlignLeft_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                frm.GetRichTextBox().SelectionAlignment = HorizontalAlignment.Left;
                UpdateAlignmentMenu();
            }
        }

        private void mnuAlignCenter_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                frm.GetRichTextBox().SelectionAlignment = HorizontalAlignment.Center;
                UpdateAlignmentMenu();
            }
        }

        private void mnuAlignRight_Click(object sender, EventArgs e)
        {
            blank frm = this.ActiveMdiChild as blank;
            if (frm != null)
            {
                frm.GetRichTextBox().SelectionAlignment = HorizontalAlignment.Right;
                UpdateAlignmentMenu();
            }
        }
        private void mnuInsert_Click(object sender, EventArgs e)
        {
            var activeChild = ActiveMdiChild as blank;
            activeChild?.InsertImage();
        }

        private void mnuImageLeft_Click(object sender, EventArgs e)
        {
            var activeChild = ActiveMdiChild as blank;
            activeChild?.SetImageAlignment(HorizontalAlignment.Left);
        }

        private void mnuImageCenter_Click(object sender, EventArgs e)
        {
            var activeChild = ActiveMdiChild as blank;
            activeChild?.SetImageAlignment(HorizontalAlignment.Center);
        }

        private void mnuImageRight_Click(object sender, EventArgs e)
        {
            var activeChild = ActiveMdiChild as blank;
            activeChild?.SetImageAlignment(HorizontalAlignment.Right);
        }
    }
}