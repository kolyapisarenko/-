﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using OOP_Lab21.Resources;

namespace OOP_Lab21
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
            ApplyLocalization();
        }

        public void ApplyLocalization()
        {
            this.Text = Resources.Resource.About_Title;
            label1.Text = Resources.Resource.About_Label1;
            label2.Text = Resources.Resource.About_Label2;
            linkLabel1.Text = Resources.Resource.About_Link;
            button1.Text = Resources.Resource.About_OK;
        }

        private void linkLabel1_Click(object sender, EventArgs e)
        {
            try
            {
                VisitLink();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    Resources.Resource.LinkError,
                    Resources.Resource.ErrorTitle,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void VisitLink()
        {
            linkLabel1.LinkVisited = true;
            Process.Start("http://" + linkLabel1.Text); // Використовуємо текст посилання як URL
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}