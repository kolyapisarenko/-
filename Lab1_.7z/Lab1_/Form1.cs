﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Lab1_
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void btnGetResult_Click(object sender, EventArgs e)
        {
            try
            {
                double x = Convert.ToDouble(txtInputX.Text);
                double y = Convert.ToDouble(txtInputY.Text);
                double result = x * Math.Log(x) + (y / (Math.Cos(x) - (x / 3)));
                lblOutputResult.Text = result.ToString();
            }
            catch
            {
                if(txtInputX.Text.Length == 0)
                {
                    txtInputX.Focus();
                }
                else
                {
                    txtInputY.Focus();
                }
            }
        }

        private void txtInputX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputX.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnGetResult.Focus();
                return;
            }
            e.Handled = true;

        }

        private void txtInputY_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputY.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnGetResult.Focus();
                return;
            }
            e.Handled = true;

        }

        private void btnCalculateResult_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtInputSide.Text);
                double h = (a * Math.Sqrt(3)) / 2;
                double S = (Math.Pow(a, 2) * Math.Sqrt(3)) / 4;
                double R = a / Math.Sqrt(3);
                double r = (a * Math.Sqrt(3)) / 6;
                lblOutputHeight.Text = h.ToString();
                lblOutputArea.Text = S.ToString();
                lblOutputR.Text = R.ToString();
                lblOutputRadius.Text = r.ToString();
            }
            catch
            {
                txtInputSide.Focus();
            }
        }

        private void txtInputSide_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputSide.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnCalculateResult.Focus();
                return;
            }
            e.Handled = true;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            try
            {
                int num = Convert.ToInt32(txtInputNum.Text);
                int first, second, third, fourth;
                first = num / 1000;
                second = (num / 100) % 10;
                third = (num / 10) % 10;
                fourth = num % 10;
                bool result = (first < second) && (second < third) && (third < fourth);
                lblOutputNumberCheck.Text = result.ToString();
            }
            catch
            {
                txtInputNum.Focus();
            }
        }

        private void txtInputNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnCheck.Focus();
                return;
            }
            e.Handled = true;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtInputSideA.Text);
                double b = Convert.ToDouble(txtInputSideB.Text);
                double c = Convert.ToDouble(txtInputSideC.Text);
                if ((a + b > c) && (b + c > a) && (a + c > b))
                {
                    double p = (a + b + c) / 2;
                    double S = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
                    lblOutputTriangleArea.Text = $"Площа трикутника - {S.ToString()}";
                }
                else
                {
                    lblOutputNoTriangle.Text = "Трикутник не існує";
                }
            }
            catch
            {
                if (txtInputSideA.Text.Length == 0)
                {
                    txtInputSideA.Focus();
                }
                else if (txtInputSideB.Text.Length == 0)
                {
                    txtInputSideB.Focus();
                }
                else
                {
                    txtInputSideC.Focus();
                }
            }
        }

        private void txtInputSideA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputSideA.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnOK.Focus();
                return;
            }
            e.Handled = true;
        }

        private void txtInputSideB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputSideB.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnOK.Focus();
                return;
            }
            e.Handled = true;
        }

        private void txtInputSideC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (txtInputSideC.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnOK.Focus();
                return;
            }
            e.Handled = true;
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                int num = Convert.ToInt32(txtInputFind.Text);
                int counter = 0;
                for (int i = 1; i <= num; i++)
                {
                    if (i % 2 != 0 && i % 3 != 0 && i % 5 != 0)
                    {
                        counter++;
                    }
                }
                lblOutputFindResult.Text = counter.ToString();
            }
            catch
            {
                txtInputFind.Focus();
            }
        }

        private void txtInputFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnFind.Focus();
                return;
            }
            e.Handled = true;
        }

        private void btnFindWords_Click(object sender, EventArgs e)
        {
            lblOutputWords.Text = "";
            string s = txtInputString.Text;
            if (s.Length == 0)
            {
                lblOutputWords.Text = "Рядок порожній";
                txtInputString.Focus();
            }
            else
            {
                string[] words = s.Split(new char[] { ' ', ',', '.', '!', '?', ':', ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var word in words)
                {
                    if (Char.ToLower(word[0]) == Char.ToLower(word[word.Length - 1]))
                    {
                        lblOutputWords.Text += word + " ";
                    }
                }
            }
        }

        private void txtInputString_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnFindWords.Focus();
                return;
            }
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
           
            lblOutputReplaceCount.Text = "";
            string s = txtInputLine.Text;
            if (s.Length == 0)
            {
                lblOutputNewLine.Text = "Рядок порожній";
                txtInputLine.Focus();
            }
            else
            {
                int counter = s.Count(c => c == ':');
                string newS = s.Replace(':', ';');
                lblOutputNewLine.Text = newS;
                lblOutputReplaceCount.Text = $"Кількість замінених символів - {counter.ToString()}";
            }
            
        }

        private void txtInputLine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                    btnReplace.Focus();
                return;
            }
        }
    }
}