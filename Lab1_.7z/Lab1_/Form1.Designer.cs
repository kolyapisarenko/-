﻿namespace Lab1_
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtInputX = new System.Windows.Forms.TextBox();
            this.txtInputY = new System.Windows.Forms.TextBox();
            this.btnGetResult = new System.Windows.Forms.Button();
            this.lblOutputResult = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCalculateResult = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblOutputRadius = new System.Windows.Forms.Label();
            this.lblOutputR = new System.Windows.Forms.Label();
            this.lblOutputArea = new System.Windows.Forms.Label();
            this.lblOutputHeight = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtInputSide = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnCheck = new System.Windows.Forms.Button();
            this.txtInputNum = new System.Windows.Forms.TextBox();
            this.lblOutputNumberCheck = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblOutputTriangleArea = new System.Windows.Forms.Label();
            this.lblOutputNoTriangle = new System.Windows.Forms.Label();
            this.txtInputSideC = new System.Windows.Forms.TextBox();
            this.txtInputSideB = new System.Windows.Forms.TextBox();
            this.txtInputSideA = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnFind = new System.Windows.Forms.Button();
            this.txtInputFind = new System.Windows.Forms.TextBox();
            this.lblOutputFindResult = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtInputString = new System.Windows.Forms.TextBox();
            this.lblOutputWords = new System.Windows.Forms.Label();
            this.btnFindWords = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtInputLine = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.lblOutputNewLine = new System.Windows.Forms.Label();
            this.lblOutputReplaceCount = new System.Windows.Forms.Label();
            this.btnReplace = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = Properties.Resources._1;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1194, 165);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(26, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Введіть значення x";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(58, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 26);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(26, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 26);
            this.label3.TabIndex = 3;
            this.label3.Text = "Введіть значення y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(26, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 26);
            this.label4.TabIndex = 4;
            this.label4.Text = "Результат";
            // 
            // txtInputX
            // 
            this.txtInputX.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputX.Location = new System.Drawing.Point(396, 178);
            this.txtInputX.Name = "txtInputX";
            this.txtInputX.Size = new System.Drawing.Size(100, 34);
            this.txtInputX.TabIndex = 5;
            this.txtInputX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputX_KeyPress);
            // 
            // txtInputY
            // 
            this.txtInputY.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputY.Location = new System.Drawing.Point(396, 251);
            this.txtInputY.Name = "txtInputY";
            this.txtInputY.Size = new System.Drawing.Size(100, 34);
            this.txtInputY.TabIndex = 6;
            this.txtInputY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputY_KeyPress);
            // 
            // btnGetResult
            // 
            this.btnGetResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnGetResult.Location = new System.Drawing.Point(150, 387);
            this.btnGetResult.Name = "btnGetResult";
            this.btnGetResult.Size = new System.Drawing.Size(161, 40);
            this.btnGetResult.TabIndex = 7;
            this.btnGetResult.Text = "Обчислити";
            this.btnGetResult.UseVisualStyleBackColor = true;
            this.btnGetResult.Click += new System.EventHandler(this.btnGetResult_Click);
            // 
            // lblOutputResult
            // 
            this.lblOutputResult.AutoSize = true;
            this.lblOutputResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputResult.Location = new System.Drawing.Point(391, 326);
            this.lblOutputResult.Name = "lblOutputResult";
            this.lblOutputResult.Size = new System.Drawing.Size(0, 26);
            this.lblOutputResult.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1214, 598);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.lblOutputResult);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnGetResult);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtInputY);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtInputX);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1206, 511);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Task1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnCalculateResult);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.lblOutputRadius);
            this.tabPage2.Controls.Add(this.lblOutputR);
            this.tabPage2.Controls.Add(this.lblOutputArea);
            this.tabPage2.Controls.Add(this.lblOutputHeight);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtInputSide);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1206, 511);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Task2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnCalculateResult
            // 
            this.btnCalculateResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCalculateResult.Location = new System.Drawing.Point(286, 451);
            this.btnCalculateResult.Name = "btnCalculateResult";
            this.btnCalculateResult.Size = new System.Drawing.Size(150, 39);
            this.btnCalculateResult.TabIndex = 11;
            this.btnCalculateResult.Text = "Обчислити";
            this.btnCalculateResult.UseVisualStyleBackColor = true;
            this.btnCalculateResult.Click += new System.EventHandler(this.btnCalculateResult_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = Properties.Resources._2;
            this.pictureBox2.Location = new System.Drawing.Point(32, 23);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1151, 87);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // lblOutputRadius
            // 
            this.lblOutputRadius.AutoSize = true;
            this.lblOutputRadius.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputRadius.Location = new System.Drawing.Point(518, 397);
            this.lblOutputRadius.Name = "lblOutputRadius";
            this.lblOutputRadius.Size = new System.Drawing.Size(0, 26);
            this.lblOutputRadius.TabIndex = 9;
            // 
            // lblOutputR
            // 
            this.lblOutputR.AutoSize = true;
            this.lblOutputR.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputR.Location = new System.Drawing.Point(518, 340);
            this.lblOutputR.Name = "lblOutputR";
            this.lblOutputR.Size = new System.Drawing.Size(0, 26);
            this.lblOutputR.TabIndex = 8;
            // 
            // lblOutputArea
            // 
            this.lblOutputArea.AutoSize = true;
            this.lblOutputArea.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputArea.Location = new System.Drawing.Point(518, 279);
            this.lblOutputArea.Name = "lblOutputArea";
            this.lblOutputArea.Size = new System.Drawing.Size(0, 26);
            this.lblOutputArea.TabIndex = 7;
            // 
            // lblOutputHeight
            // 
            this.lblOutputHeight.AutoSize = true;
            this.lblOutputHeight.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputHeight.Location = new System.Drawing.Point(517, 220);
            this.lblOutputHeight.Name = "lblOutputHeight";
            this.lblOutputHeight.Size = new System.Drawing.Size(0, 26);
            this.lblOutputHeight.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(66, 397);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(206, 26);
            this.label9.TabIndex = 5;
            this.label9.Text = "Вписаний радіус r =";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(66, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(216, 26);
            this.label8.TabIndex = 4;
            this.label8.Text = "Описаний радіус R =";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(66, 279);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(233, 26);
            this.label7.TabIndex = 3;
            this.label7.Text = "Площа трикутника S =";
            // 
            // txtInputSide
            // 
            this.txtInputSide.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputSide.Location = new System.Drawing.Point(522, 152);
            this.txtInputSide.Name = "txtInputSide";
            this.txtInputSide.Size = new System.Drawing.Size(100, 34);
            this.txtInputSide.TabIndex = 2;
            this.txtInputSide.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputSide_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(66, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(234, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Висота трикутника h =";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(66, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(379, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "Введіть довжину сторони трикутника";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnCheck);
            this.tabPage3.Controls.Add(this.txtInputNum);
            this.tabPage3.Controls.Add(this.lblOutputNumberCheck);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1206, 511);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Task3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnCheck
            // 
            this.btnCheck.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCheck.Location = new System.Drawing.Point(134, 340);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(155, 43);
            this.btnCheck.TabIndex = 5;
            this.btnCheck.Text = "Перевірити";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // txtInputNum
            // 
            this.txtInputNum.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputNum.Location = new System.Drawing.Point(253, 165);
            this.txtInputNum.MaxLength = 4;
            this.txtInputNum.Name = "txtInputNum";
            this.txtInputNum.Size = new System.Drawing.Size(100, 34);
            this.txtInputNum.TabIndex = 4;
            this.txtInputNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputNum_KeyPress);
            // 
            // lblOutputNumberCheck
            // 
            this.lblOutputNumberCheck.AutoSize = true;
            this.lblOutputNumberCheck.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputNumberCheck.Location = new System.Drawing.Point(248, 248);
            this.lblOutputNumberCheck.Name = "lblOutputNumberCheck";
            this.lblOutputNumberCheck.Size = new System.Drawing.Size(0, 26);
            this.lblOutputNumberCheck.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(48, 248);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 26);
            this.label11.TabIndex = 2;
            this.label11.Text = "Результат";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(48, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 26);
            this.label10.TabIndex = 1;
            this.label10.Text = "Введіть число";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = Properties.Resources._3;
            this.pictureBox3.Location = new System.Drawing.Point(23, 21);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(1163, 112);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnOK);
            this.tabPage4.Controls.Add(this.lblOutputTriangleArea);
            this.tabPage4.Controls.Add(this.lblOutputNoTriangle);
            this.tabPage4.Controls.Add(this.txtInputSideC);
            this.tabPage4.Controls.Add(this.txtInputSideB);
            this.tabPage4.Controls.Add(this.txtInputSideA);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1206, 569);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Task4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnOK.Location = new System.Drawing.Point(183, 464);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(166, 44);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "ОК";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblOutputTriangleArea
            // 
            this.lblOutputTriangleArea.AutoSize = true;
            this.lblOutputTriangleArea.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputTriangleArea.Location = new System.Drawing.Point(60, 399);
            this.lblOutputTriangleArea.Name = "lblOutputTriangleArea";
            this.lblOutputTriangleArea.Size = new System.Drawing.Size(0, 26);
            this.lblOutputTriangleArea.TabIndex = 8;
            // 
            // lblOutputNoTriangle
            // 
            this.lblOutputNoTriangle.AutoSize = true;
            this.lblOutputNoTriangle.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputNoTriangle.Location = new System.Drawing.Point(60, 354);
            this.lblOutputNoTriangle.Name = "lblOutputNoTriangle";
            this.lblOutputNoTriangle.Size = new System.Drawing.Size(0, 26);
            this.lblOutputNoTriangle.TabIndex = 7;
            // 
            // txtInputSideC
            // 
            this.txtInputSideC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputSideC.Location = new System.Drawing.Point(331, 269);
            this.txtInputSideC.Name = "txtInputSideC";
            this.txtInputSideC.Size = new System.Drawing.Size(100, 34);
            this.txtInputSideC.TabIndex = 6;
            this.txtInputSideC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputSideC_KeyPress);
            // 
            // txtInputSideB
            // 
            this.txtInputSideB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputSideB.Location = new System.Drawing.Point(331, 200);
            this.txtInputSideB.Name = "txtInputSideB";
            this.txtInputSideB.Size = new System.Drawing.Size(100, 34);
            this.txtInputSideB.TabIndex = 5;
            this.txtInputSideB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputSideB_KeyPress);
            // 
            // txtInputSideA
            // 
            this.txtInputSideA.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputSideA.Location = new System.Drawing.Point(331, 134);
            this.txtInputSideA.Name = "txtInputSideA";
            this.txtInputSideA.Size = new System.Drawing.Size(100, 34);
            this.txtInputSideA.TabIndex = 4;
            this.txtInputSideA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputSideA_KeyPress);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = Properties.Resources._4;
            this.pictureBox4.Location = new System.Drawing.Point(24, 21);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(1158, 69);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(60, 277);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(186, 26);
            this.label14.TabIndex = 2;
            this.label14.Text = "Введіть сторону c";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(60, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(188, 26);
            this.label13.TabIndex = 1;
            this.label13.Text = "Введіть сторону b";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(60, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 26);
            this.label12.TabIndex = 0;
            this.label12.Text = "Введіть сторону a";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.lblOutputFindResult);
            this.tabPage5.Controls.Add(this.txtInputFind);
            this.tabPage5.Controls.Add(this.btnFind);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1206, 569);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Task5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnFindWords);
            this.tabPage6.Controls.Add(this.lblOutputWords);
            this.tabPage6.Controls.Add(this.txtInputString);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.pictureBox6);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1206, 569);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Task6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnReplace);
            this.tabPage7.Controls.Add(this.lblOutputReplaceCount);
            this.tabPage7.Controls.Add(this.lblOutputNewLine);
            this.tabPage7.Controls.Add(this.label20);
            this.tabPage7.Controls.Add(this.txtInputLine);
            this.tabPage7.Controls.Add(this.label19);
            this.tabPage7.Controls.Add(this.pictureBox7);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1206, 569);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Task7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = Properties.Resources._5;
            this.pictureBox5.Location = new System.Drawing.Point(20, 21);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(1183, 69);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(40, 131);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(261, 26);
            this.label15.TabIndex = 1;
            this.label15.Text = "Введіть натуральне число";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(42, 192);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 26);
            this.label16.TabIndex = 2;
            this.label16.Text = "Відповідь";
            // 
            // btnFind
            // 
            this.btnFind.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFind.Location = new System.Drawing.Point(225, 275);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(153, 37);
            this.btnFind.TabIndex = 3;
            this.btnFind.Text = "Знайти";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // txtInputFind
            // 
            this.txtInputFind.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputFind.Location = new System.Drawing.Point(433, 123);
            this.txtInputFind.Name = "txtInputFind";
            this.txtInputFind.Size = new System.Drawing.Size(100, 34);
            this.txtInputFind.TabIndex = 4;
            this.txtInputFind.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputFind_KeyPress);
            // 
            // lblOutputFindResult
            // 
            this.lblOutputFindResult.AutoSize = true;
            this.lblOutputFindResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputFindResult.Location = new System.Drawing.Point(428, 192);
            this.lblOutputFindResult.Name = "lblOutputFindResult";
            this.lblOutputFindResult.Size = new System.Drawing.Size(0, 26);
            this.lblOutputFindResult.TabIndex = 5;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = Properties.Resources._6;
            this.pictureBox6.Location = new System.Drawing.Point(18, 18);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(1185, 68);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(13, 119);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(149, 26);
            this.label17.TabIndex = 1;
            this.label17.Text = "Введіть рядок";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(13, 196);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 26);
            this.label18.TabIndex = 2;
            this.label18.Text = "Результат";
            // 
            // txtInputString
            // 
            this.txtInputString.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputString.Location = new System.Drawing.Point(184, 111);
            this.txtInputString.Name = "txtInputString";
            this.txtInputString.Size = new System.Drawing.Size(730, 34);
            this.txtInputString.TabIndex = 3;
            this.txtInputString.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputString_KeyPress);
            // 
            // lblOutputWords
            // 
            this.lblOutputWords.AutoSize = true;
            this.lblOutputWords.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputWords.Location = new System.Drawing.Point(179, 196);
            this.lblOutputWords.Name = "lblOutputWords";
            this.lblOutputWords.Size = new System.Drawing.Size(0, 26);
            this.lblOutputWords.TabIndex = 4;
            // 
            // btnFindWords
            // 
            this.btnFindWords.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFindWords.Location = new System.Drawing.Point(97, 288);
            this.btnFindWords.Name = "btnFindWords";
            this.btnFindWords.Size = new System.Drawing.Size(160, 38);
            this.btnFindWords.TabIndex = 5;
            this.btnFindWords.Text = "Знайти слова";
            this.btnFindWords.UseVisualStyleBackColor = true;
            this.btnFindWords.Click += new System.EventHandler(this.btnFindWords_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = Properties.Resources._7;
            this.pictureBox7.Location = new System.Drawing.Point(12, 16);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(1191, 66);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(28, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(149, 26);
            this.label19.TabIndex = 1;
            this.label19.Text = "Введіть рядок";
            // 
            // txtInputLine
            // 
            this.txtInputLine.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtInputLine.Location = new System.Drawing.Point(250, 105);
            this.txtInputLine.Name = "txtInputLine";
            this.txtInputLine.Size = new System.Drawing.Size(918, 34);
            this.txtInputLine.TabIndex = 2;
            this.txtInputLine.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputLine_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(28, 177);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(196, 26);
            this.label20.TabIndex = 3;
            this.label20.Text = "Рядок після заміни";
            // 
            // lblOutputNewLine
            // 
            this.lblOutputNewLine.AutoSize = true;
            this.lblOutputNewLine.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputNewLine.Location = new System.Drawing.Point(245, 177);
            this.lblOutputNewLine.Name = "lblOutputNewLine";
            this.lblOutputNewLine.Size = new System.Drawing.Size(0, 26);
            this.lblOutputNewLine.TabIndex = 4;
            // 
            // lblOutputReplaceCount
            // 
            this.lblOutputReplaceCount.AutoSize = true;
            this.lblOutputReplaceCount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOutputReplaceCount.Location = new System.Drawing.Point(28, 242);
            this.lblOutputReplaceCount.Name = "lblOutputReplaceCount";
            this.lblOutputReplaceCount.Size = new System.Drawing.Size(0, 26);
            this.lblOutputReplaceCount.TabIndex = 5;
            // 
            // btnReplace
            // 
            this.btnReplace.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReplace.Location = new System.Drawing.Point(108, 321);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(153, 39);
            this.btnReplace.TabIndex = 6;
            this.btnReplace.Text = "Замінити";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1238, 622);
            this.Controls.Add(this.tabControl1);
            this.Name = "mainForm";
            this.Text = "Lab1_Pysarenko";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtInputX;
        private System.Windows.Forms.TextBox txtInputY;
        private System.Windows.Forms.Button btnGetResult;
        private System.Windows.Forms.Label lblOutputResult;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblOutputRadius;
        private System.Windows.Forms.Label lblOutputR;
        private System.Windows.Forms.Label lblOutputArea;
        private System.Windows.Forms.Label lblOutputHeight;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtInputSide;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCalculateResult;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.TextBox txtInputNum;
        private System.Windows.Forms.Label lblOutputNumberCheck;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblOutputTriangleArea;
        private System.Windows.Forms.Label lblOutputNoTriangle;
        private System.Windows.Forms.TextBox txtInputSideC;
        private System.Windows.Forms.TextBox txtInputSideB;
        private System.Windows.Forms.TextBox txtInputSideA;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblOutputFindResult;
        private System.Windows.Forms.TextBox txtInputFind;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btnFindWords;
        private System.Windows.Forms.Label lblOutputWords;
        private System.Windows.Forms.TextBox txtInputString;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.Label lblOutputReplaceCount;
        private System.Windows.Forms.Label lblOutputNewLine;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtInputLine;
        private System.Windows.Forms.Label label19;
    }
}

