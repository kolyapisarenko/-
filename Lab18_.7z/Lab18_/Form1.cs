﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab18_
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }
        private int n;
        private double[] array;
        private double minElement = 10000000000000000000;
        private int counter = 0;
        private int rows;
        private int cols;
        private double[,] matrix;
        private int counter1;

        private void txtInputArraySize_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnSetArraySize.Focus();
                    btnSetMatrixSize.Focus();
                }
                return;
            }
            e.Handled = true;

        }

        private void txtInputElement_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (textBox.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnSaveElement.Focus();
                    btnSaveMatrixElement.Focus();
                }
                return;
            }
            e.Handled = true;

        }

        private void btnSetArraySize_Click(object sender, EventArgs e)
        {
            try
            {
                txtInputElement.Enabled = true;
                txtInputElement.Clear();
                lstBoxInputArray.Items.Clear();
                lstBoxChangedArray.Items.Clear();
                lblMinElement.Text = "";
                lblSumOfElementsBetween.Text = "";
                counter = 0;
                n = Convert.ToInt32(txtInputArraySize.Text);
                array = new double[n];
                txtInputElement.Focus();
            }
            catch
            {
                txtInputArraySize.Focus();
            }

        }

        private void btnSaveElement_Click(object sender, EventArgs e)
        {
            try
            {
                if (counter < n)
                {
                    double el = Convert.ToDouble(txtInputElement.Text);
                    if (el < minElement)
                    {
                        minElement = el;
                    }
                    array[counter] = el;
                    counter++;
                    if (counter == n)
                    {
                        txtInputElement.Enabled = false;
                        lstBoxInputArray.Items.Clear();
                        foreach (double element in array)
                        {
                            lstBoxInputArray.Items.Add(element);
                        }
                        lblMinElement.Text = $"Найменший елемент {minElement}";
                        return;
                    }
                    txtInputElement.Clear();
                    txtInputElement.Focus();
                }
            }
            catch
            {
                txtInputElement.Focus();
            }

        }

        private void btnGetResult_Click(object sender, EventArgs e)
        {
            double sumBetweenPositives = 0;
            int firstPositiveIndex = -1, secondPositiveIndex = -1;

            for (int i = 0; i < n; i++)
            {
                if (array[i] > 0)
                {
                    if (firstPositiveIndex == -1)
                    {
                        firstPositiveIndex = i;
                    }
                    else if (secondPositiveIndex == -1)
                    {
                        secondPositiveIndex = i;
                    }
                }
            }

            if (firstPositiveIndex != -1 && secondPositiveIndex != -1 && secondPositiveIndex - firstPositiveIndex > 1)
            {
                for (int i = firstPositiveIndex + 1; i < secondPositiveIndex; i++)
                {
                    sumBetweenPositives += array[i];
                }
                lblSumOfElementsBetween.Text = $"Сума елементів між першим і другим додатними {sumBetweenPositives}";
            }
            else
            {
                lblSumOfElementsBetween.Text = "Немає двох додатних чисел для підрахунку суми";
            }

            lstBoxChangedArray.Items.Clear();
            var sortedArray = array.Where(x => x == 0).Concat(array.Where(x => x != 0)).ToArray();
            foreach (var item in sortedArray)
            {
                lstBoxChangedArray.Items.Add(item);
            }

        }

        private void btnSetMatrixSize_Click(object sender, EventArgs e)
        {
            try
            {
                txtInputMatrixElement.Enabled = true;
                lstBoxInputMatrix.Items.Clear();
                txtInputMatrixElement.Clear();
                rows = Convert.ToInt32(txtInputRows.Text);
                cols = Convert.ToInt32(txtInputCols.Text);
                matrix = new double[rows, cols];
                counter1 = 0;
                txtInputMatrixElement.Focus();
            }
            catch
            {
                if (txtInputRows.Text.Length == 0)
                {
                    txtInputRows.Focus();
                }
                else
                {
                    txtInputCols.Focus();
                }
            }

        }

        private void btnSaveMatrixElement_Click(object sender, EventArgs e)
        {
            try
            {
                if (counter1 < rows * cols)
                {
                    double el = Convert.ToDouble(txtInputMatrixElement.Text);
                    int currentRow = counter1 / cols;
                    int currentCol = counter1 % cols;
                    matrix[currentRow, currentCol] = el;
                    counter1++;
                    if (counter1 == rows * cols)
                    {
                        txtInputMatrixElement.Enabled = false;
                        lstBoxInputMatrix.Items.Clear();
                        for (int i = 0; i < rows; i++)
                        {
                            string rowText = "";
                            for (int j = 0; j < cols; j++)
                            {
                                rowText += matrix[i, j] + " ";
                            }
                            lstBoxInputMatrix.Items.Add(rowText);
                        }
                        return;
                    }
                    txtInputMatrixElement.Clear();
                    txtInputMatrixElement.Focus();
                }
            }
            catch
            {
                txtInputMatrixElement.Focus();
            }

        }

        private void btnWhichIsSmaller_Click(object sender, EventArgs e)
        {
            if (matrix == null || rows == 0 || cols == 0) return;

            double bottomLeft = matrix[rows - 1, 0];
            double bottomRight = matrix[rows - 1, cols - 1];
            double topRight = matrix[0, cols - 1];

            double minBottom = Math.Min(bottomLeft, bottomRight);
            double minTopBottom = Math.Min(topRight, bottomLeft);

            lblSmallerElement1.Text = $"Мінімальний серед нижніх {minBottom}";
            lblSmallerElement2.Text = $"Мінімальний між верхнім правим і нижнім лівим {minTopBottom}";

        }
    }
}
