﻿namespace Lab18_
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnGetResult = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lstBoxChangedArray = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lstBoxInputArray = new System.Windows.Forms.ListBox();
            this.lblSumOfElementsBetween = new System.Windows.Forms.Label();
            this.lblMinElement = new System.Windows.Forms.Label();
            this.btnSaveElement = new System.Windows.Forms.Button();
            this.txtInputElement = new System.Windows.Forms.TextBox();
            this.btnSetArraySize = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInputArraySize = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSetMatrixSize = new System.Windows.Forms.Button();
            this.txtInputRows = new System.Windows.Forms.TextBox();
            this.txtInputCols = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtInputMatrixElement = new System.Windows.Forms.TextBox();
            this.btnSaveMatrixElement = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.lstBoxInputMatrix = new System.Windows.Forms.ListBox();
            this.lblSmallerElement1 = new System.Windows.Forms.Label();
            this.lblSmallerElement2 = new System.Windows.Forms.Label();
            this.btnWhichIsSmaller = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1305, 599);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1297, 564);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Умова";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Lab18_.Properties.Resources._1;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1285, 561);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnGetResult);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.lstBoxChangedArray);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.lstBoxInputArray);
            this.tabPage2.Controls.Add(this.lblSumOfElementsBetween);
            this.tabPage2.Controls.Add(this.lblMinElement);
            this.tabPage2.Controls.Add(this.btnSaveElement);
            this.tabPage2.Controls.Add(this.txtInputElement);
            this.tabPage2.Controls.Add(this.btnSetArraySize);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtInputArraySize);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1297, 564);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Одновимірний масив";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnGetResult
            // 
            this.btnGetResult.Location = new System.Drawing.Point(273, 189);
            this.btnGetResult.Name = "btnGetResult";
            this.btnGetResult.Size = new System.Drawing.Size(183, 66);
            this.btnGetResult.TabIndex = 12;
            this.btnGetResult.Text = "Отримати результат";
            this.btnGetResult.UseVisualStyleBackColor = true;
            this.btnGetResult.Click += new System.EventHandler(this.btnGetResult_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(840, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(237, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Масив після перетворення";
            // 
            // lstBoxChangedArray
            // 
            this.lstBoxChangedArray.FormattingEnabled = true;
            this.lstBoxChangedArray.ItemHeight = 22;
            this.lstBoxChangedArray.Location = new System.Drawing.Point(844, 69);
            this.lstBoxChangedArray.Name = "lstBoxChangedArray";
            this.lstBoxChangedArray.Size = new System.Drawing.Size(133, 180);
            this.lstBoxChangedArray.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(588, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 22);
            this.label5.TabIndex = 9;
            this.label5.Text = "Введено масив";
            // 
            // lstBoxInputArray
            // 
            this.lstBoxInputArray.FormattingEnabled = true;
            this.lstBoxInputArray.ItemHeight = 22;
            this.lstBoxInputArray.Location = new System.Drawing.Point(592, 69);
            this.lstBoxInputArray.Name = "lstBoxInputArray";
            this.lstBoxInputArray.Size = new System.Drawing.Size(133, 180);
            this.lstBoxInputArray.TabIndex = 8;
            // 
            // lblSumOfElementsBetween
            // 
            this.lblSumOfElementsBetween.AutoSize = true;
            this.lblSumOfElementsBetween.Location = new System.Drawing.Point(19, 335);
            this.lblSumOfElementsBetween.Name = "lblSumOfElementsBetween";
            this.lblSumOfElementsBetween.Size = new System.Drawing.Size(0, 22);
            this.lblSumOfElementsBetween.TabIndex = 7;
            // 
            // lblMinElement
            // 
            this.lblMinElement.AutoSize = true;
            this.lblMinElement.Location = new System.Drawing.Point(19, 285);
            this.lblMinElement.Name = "lblMinElement";
            this.lblMinElement.Size = new System.Drawing.Size(0, 22);
            this.lblMinElement.TabIndex = 6;
            // 
            // btnSaveElement
            // 
            this.btnSaveElement.Location = new System.Drawing.Point(23, 189);
            this.btnSaveElement.Name = "btnSaveElement";
            this.btnSaveElement.Size = new System.Drawing.Size(192, 66);
            this.btnSaveElement.TabIndex = 5;
            this.btnSaveElement.Text = "Зберегти елемент масиву";
            this.btnSaveElement.UseVisualStyleBackColor = true;
            this.btnSaveElement.Click += new System.EventHandler(this.btnSaveElement_Click);
            // 
            // txtInputElement
            // 
            this.txtInputElement.Location = new System.Drawing.Point(273, 131);
            this.txtInputElement.Name = "txtInputElement";
            this.txtInputElement.Size = new System.Drawing.Size(100, 30);
            this.txtInputElement.TabIndex = 4;
            this.txtInputElement.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputElement_KeyPress);
            // 
            // btnSetArraySize
            // 
            this.btnSetArraySize.Location = new System.Drawing.Point(23, 66);
            this.btnSetArraySize.Name = "btnSetArraySize";
            this.btnSetArraySize.Size = new System.Drawing.Size(192, 63);
            this.btnSetArraySize.TabIndex = 3;
            this.btnSetArraySize.Text = "Задати розмір масиву";
            this.btnSetArraySize.UseVisualStyleBackColor = true;
            this.btnSetArraySize.Click += new System.EventHandler(this.btnSetArraySize_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Введіть елемент масиву";
            // 
            // txtInputArraySize
            // 
            this.txtInputArraySize.Location = new System.Drawing.Point(394, 19);
            this.txtInputArraySize.Name = "txtInputArraySize";
            this.txtInputArraySize.Size = new System.Drawing.Size(100, 30);
            this.txtInputArraySize.TabIndex = 1;
            this.txtInputArraySize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputArraySize_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введіть кількість елементів масиву";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnWhichIsSmaller);
            this.tabPage3.Controls.Add(this.lblSmallerElement2);
            this.tabPage3.Controls.Add(this.lblSmallerElement1);
            this.tabPage3.Controls.Add(this.lstBoxInputMatrix);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.btnSaveMatrixElement);
            this.tabPage3.Controls.Add(this.txtInputMatrixElement);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.txtInputCols);
            this.tabPage3.Controls.Add(this.txtInputRows);
            this.tabPage3.Controls.Add(this.btnSetMatrixSize);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1297, 564);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Двовимірний масив";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "Введіть кількість рядків";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(237, 22);
            this.label4.TabIndex = 1;
            this.label4.Text = "Введіть кількість стовпців";
            // 
            // btnSetMatrixSize
            // 
            this.btnSetMatrixSize.Location = new System.Drawing.Point(28, 109);
            this.btnSetMatrixSize.Name = "btnSetMatrixSize";
            this.btnSetMatrixSize.Size = new System.Drawing.Size(189, 59);
            this.btnSetMatrixSize.TabIndex = 2;
            this.btnSetMatrixSize.Text = "Задати розмір матриці";
            this.btnSetMatrixSize.UseVisualStyleBackColor = true;
            this.btnSetMatrixSize.Click += new System.EventHandler(this.btnSetMatrixSize_Click);
            // 
            // txtInputRows
            // 
            this.txtInputRows.Location = new System.Drawing.Point(291, 16);
            this.txtInputRows.Name = "txtInputRows";
            this.txtInputRows.Size = new System.Drawing.Size(100, 30);
            this.txtInputRows.TabIndex = 3;
            this.txtInputRows.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputArraySize_KeyPress);
            // 
            // txtInputCols
            // 
            this.txtInputCols.Location = new System.Drawing.Point(291, 63);
            this.txtInputCols.Name = "txtInputCols";
            this.txtInputCols.Size = new System.Drawing.Size(100, 30);
            this.txtInputCols.TabIndex = 4;
            this.txtInputCols.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputArraySize_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(223, 22);
            this.label7.TabIndex = 5;
            this.label7.Text = "Введіть елемент матриці";
            // 
            // txtInputMatrixElement
            // 
            this.txtInputMatrixElement.Location = new System.Drawing.Point(291, 187);
            this.txtInputMatrixElement.Name = "txtInputMatrixElement";
            this.txtInputMatrixElement.Size = new System.Drawing.Size(100, 30);
            this.txtInputMatrixElement.TabIndex = 6;
            this.txtInputMatrixElement.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInputElement_KeyPress);
            // 
            // btnSaveMatrixElement
            // 
            this.btnSaveMatrixElement.Location = new System.Drawing.Point(28, 257);
            this.btnSaveMatrixElement.Name = "btnSaveMatrixElement";
            this.btnSaveMatrixElement.Size = new System.Drawing.Size(213, 65);
            this.btnSaveMatrixElement.TabIndex = 7;
            this.btnSaveMatrixElement.Text = "Зберегти елемент матриці";
            this.btnSaveMatrixElement.UseVisualStyleBackColor = true;
            this.btnSaveMatrixElement.Click += new System.EventHandler(this.btnSaveMatrixElement_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(590, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(163, 22);
            this.label8.TabIndex = 8;
            this.label8.Text = "Введено матрицю";
            // 
            // lstBoxInputMatrix
            // 
            this.lstBoxInputMatrix.FormattingEnabled = true;
            this.lstBoxInputMatrix.ItemHeight = 22;
            this.lstBoxInputMatrix.Location = new System.Drawing.Point(594, 71);
            this.lstBoxInputMatrix.Name = "lstBoxInputMatrix";
            this.lstBoxInputMatrix.Size = new System.Drawing.Size(120, 136);
            this.lstBoxInputMatrix.TabIndex = 9;
            // 
            // lblSmallerElement1
            // 
            this.lblSmallerElement1.AutoSize = true;
            this.lblSmallerElement1.Location = new System.Drawing.Point(590, 247);
            this.lblSmallerElement1.Name = "lblSmallerElement1";
            this.lblSmallerElement1.Size = new System.Drawing.Size(0, 22);
            this.lblSmallerElement1.TabIndex = 10;
            // 
            // lblSmallerElement2
            // 
            this.lblSmallerElement2.AutoSize = true;
            this.lblSmallerElement2.Location = new System.Drawing.Point(590, 300);
            this.lblSmallerElement2.Name = "lblSmallerElement2";
            this.lblSmallerElement2.Size = new System.Drawing.Size(0, 22);
            this.lblSmallerElement2.TabIndex = 11;
            // 
            // btnWhichIsSmaller
            // 
            this.btnWhichIsSmaller.Location = new System.Drawing.Point(830, 71);
            this.btnWhichIsSmaller.Name = "btnWhichIsSmaller";
            this.btnWhichIsSmaller.Size = new System.Drawing.Size(132, 44);
            this.btnWhichIsSmaller.TabIndex = 12;
            this.btnWhichIsSmaller.Text = "Визначити";
            this.btnWhichIsSmaller.UseVisualStyleBackColor = true;
            this.btnWhichIsSmaller.Click += new System.EventHandler(this.btnWhichIsSmaller_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1329, 623);
            this.Controls.Add(this.tabControl1);
            this.Name = "mainForm";
            this.Text = "Lab18_Pysarenko";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnSaveElement;
        private System.Windows.Forms.TextBox txtInputElement;
        private System.Windows.Forms.Button btnSetArraySize;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInputArraySize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstBoxChangedArray;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstBoxInputArray;
        private System.Windows.Forms.Label lblSumOfElementsBetween;
        private System.Windows.Forms.Label lblMinElement;
        private System.Windows.Forms.Button btnGetResult;
        private System.Windows.Forms.Label lblSmallerElement2;
        private System.Windows.Forms.Label lblSmallerElement1;
        private System.Windows.Forms.ListBox lstBoxInputMatrix;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSaveMatrixElement;
        private System.Windows.Forms.TextBox txtInputMatrixElement;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtInputCols;
        private System.Windows.Forms.TextBox txtInputRows;
        private System.Windows.Forms.Button btnSetMatrixSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnWhichIsSmaller;
    }
}

