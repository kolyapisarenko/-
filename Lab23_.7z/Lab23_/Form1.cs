﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab23_
{
    public partial class Form1 : Form
    {
        private float r = 0f;
        private float h = 0f;
        private float tMin = 0f;
        private float tMax = 0f;
        private float scale = 50.0f;
        private PointF origin;
        private bool isDragging = false;
        private Point lastMousePosition;
        private const int ControlAreaHeight = 150;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.Paint += Form1_Paint;
            this.MouseWheel += Form1_MouseWheel;
            this.MouseDown += Form1_MouseDown;
            this.MouseMove += Form1_MouseMove;
            this.MouseUp += Form1_MouseUp;
            this.Resize += (s, e) => this.Invalidate();

            origin = new PointF(this.ClientSize.Width / 2, ControlAreaHeight + (this.ClientSize.Height - ControlAreaHeight) / 2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            try
            {
                r = Convert.ToSingle(txtR.Text);
                h = Convert.ToSingle(txtH.Text);
                tMax = Convert.ToSingle(txtTMax.Text);

                this.Invalidate();
            }
            catch
            {
                if (txtR.Text.Length == 0)
                {
                    txtR.Focus();
                }
                else if (txtH.Text.Length == 0)
                {
                    txtH.Focus();
                }
                else
                {
                    txtTMax.Focus();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtR.Text = "";
            txtH.Text = "";
            txtTMax.Text = "";
            r = 0f;
            h = 0f;
            tMax = 0f;
            scale = 50.0f;
            origin = new PointF(this.ClientSize.Width / 2, ControlAreaHeight + (this.ClientSize.Height - ControlAreaHeight) / 2);
            this.Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            DrawAxes(g);
            DrawLines(g);
        }

        private void DrawAxes(Graphics g)
        {
            Rectangle drawingArea = new Rectangle(0, ControlAreaHeight, this.ClientSize.Width, this.ClientSize.Height - ControlAreaHeight);
            g.SetClip(drawingArea);

            Pen axisPen = new Pen(Color.Black, 1.5f);
            Font labelFont = new Font("Arial", 8);
            Brush labelBrush = Brushes.Black;

            g.DrawLine(axisPen, 0, origin.Y, this.ClientSize.Width, origin.Y);
            g.DrawLine(axisPen, origin.X, ControlAreaHeight, origin.X, this.ClientSize.Height);

            g.DrawLine(axisPen, this.ClientSize.Width - 10, origin.Y - 5, this.ClientSize.Width, origin.Y);
            g.DrawLine(axisPen, this.ClientSize.Width - 10, origin.Y + 5, this.ClientSize.Width, origin.Y);
            g.DrawLine(axisPen, origin.X - 5, ControlAreaHeight + 10, origin.X, ControlAreaHeight);
            g.DrawLine(axisPen, origin.X + 5, ControlAreaHeight + 10, origin.X, ControlAreaHeight);
           
            g.DrawString("X", labelFont, labelBrush, this.ClientSize.Width - 20, origin.Y + 10);
            g.DrawString("Y", labelFont, labelBrush, origin.X + 10, ControlAreaHeight);

            for (int x = (int)(origin.X % scale); x < this.ClientSize.Width; x += (int)scale)
            {
                float worldX = (x - origin.X) / scale;
                g.DrawLine(Pens.Black, x, origin.Y - 3, x, origin.Y + 3);
                g.DrawString(worldX.ToString("0.0"), labelFont, labelBrush, x - 10, origin.Y + 5);
            }

            for (int y = (int)(origin.Y % scale); y < this.ClientSize.Height; y += (int)scale)
            {
                float worldY = -(y - origin.Y) / scale;
                g.DrawLine(Pens.Black, origin.X - 3, y, origin.X + 3, y);
                g.DrawString(worldY.ToString("0.0"), labelFont, labelBrush, origin.X + 10, y - 8);
            }

            g.ResetClip();
        }

        private void DrawLines(Graphics g)
        {
            if (r == 0 && h == 0) return;

            Rectangle drawingArea = new Rectangle(0, ControlAreaHeight, this.ClientSize.Width, this.ClientSize.Height - ControlAreaHeight);
            g.SetClip(drawingArea);

            Pen horizPen = new Pen(Color.Red, 2f);
            Pen vertPen = new Pen(Color.Green, 2f);
            Brush pointBrush = Brushes.Blue;
            Font labelFont = new Font("Arial", 9);
            Brush labelBrush = Brushes.Black;

            float t = tMax;
            float xFixed = r * t - h * (float)Math.Sin(t);
            float yFixed = r - h * (float)Math.Cos(t);

            float xScreen = origin.X + xFixed * scale;
            float yScreen = origin.Y - yFixed * scale;

            g.DrawLine(horizPen, 0, yScreen, this.ClientSize.Width, yScreen);

            g.DrawLine(vertPen, xScreen, ControlAreaHeight, xScreen, this.ClientSize.Height);

            g.FillEllipse(pointBrush, xScreen - 4, yScreen - 4, 8, 8);

            string coords = $"x: {xFixed:0.00}; y: {yFixed:0.00}";
            g.DrawString(coords, labelFont, labelBrush, xScreen + 6, yScreen - 20);

            g.ResetClip();
        }



        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Y > ControlAreaHeight)
            {
                float zoomFactor = 1.1f;
                scale *= (e.Delta > 0) ? zoomFactor : 1 / zoomFactor;
                scale = Clamp(scale, 1, 500);
                this.Invalidate();
            }
        }

        private float Clamp(float value, float min, float max)
        {
            return Math.Min(Math.Max(value, min), max);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {   
            if (e.Button == MouseButtons.Left && e.Y > ControlAreaHeight)
            {
                isDragging = true;
                lastMousePosition = e.Location;
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                origin.X += e.X - lastMousePosition.X;
                origin.Y += e.Y - lastMousePosition.Y;
                lastMousePosition = e.Location;
                this.Invalidate();
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                isDragging = false;
        }

        private void txtR_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (textBox.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnDraw.Focus();
                }
                return;
            }
            e.Handled = true;
        }
    }
}