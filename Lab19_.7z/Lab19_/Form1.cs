﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab19_
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInputString.Clear();
            lblCheckResult.Text = "";
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string str = txtInputString.Text;
            bool check = true;
            if (string.IsNullOrEmpty(str)) check = false;
            if (str[0] == '+' || str[0] == '-')
            {
                if (str.Length == 1) check = false;
                str = str.Substring(1);
            }
            check = str.All(char.IsDigit);
            if (check)
            {
                lblCheckResult.Text = "Рядок містить запис числа";
            }
            else
            {
                lblCheckResult.Text = "Введено набір символів що не є представленням числа";
            }
        }

        private void txtInputString_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnCheck.Focus();
                }
                return;
            }

        }
    }
}
