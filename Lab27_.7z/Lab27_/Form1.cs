﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lab27_
{
    public partial class Form1 : Form
    {
        public List<String> checkedDirs = new List<string>();
        private Color defaultNodeColor = Color.FromArgb(240, 240, 240);
        private Color directoryColor = Color.FromArgb(220, 235, 255);
        private Color fileColor = Color.FromArgb(255, 240, 240);

        public Form1()
        {
            InitializeComponent();
            this.Font = new Font("Times New Roman", 14);
            this.BackColor = Color.FromArgb(250, 245, 255);

            LoadDrives();
        }

        private void LoadDrives()
        {
            treeViewExplorer.Nodes.Clear();
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
            {
                if (drive.IsReady)
                {
                    TreeNode node = treeViewExplorer.Nodes.Add(drive.Name);
                    node.Tag = "drive";
                    node.NodeFont = new Font("Times New Roman", 14, FontStyle.Bold);
                }
            }
        }

        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;

            string path = treeViewExplorer.SelectedNode.FullPath;
            string shortPath = Path.GetFileName(path);

            try
            {
                if (File.Exists(path))
                {
                    UpdateFileInfo(path, shortPath);
                    return;
                }

                if (!checkedDirs.Contains(path))
                {
                    checkedDirs.Add(path);
                    treeViewExplorer.SelectedNode.Nodes.Clear();

                    foreach (string dir in Directory.GetDirectories(path))
                    {
                        TreeNode child = treeViewExplorer.SelectedNode.Nodes.Add(Path.GetFileName(dir));
                        child.Tag = "folder";
                        child.NodeFont = new Font("Times New Roman", 14);
                        child.BackColor = directoryColor;
                    }

                    foreach (string file in Directory.GetFiles(path))
                    {
                        TreeNode child = treeViewExplorer.SelectedNode.Nodes.Add(Path.GetFileName(file));
                        child.Tag = "file";
                        child.NodeFont = new Font("Times New Roman", 14);
                        child.BackColor = fileColor;
                    }
                }
                treeViewExplorer.SelectedNode.Expand();
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Доступ заборонено до: " + path, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateFileInfo(string path, string shortPath)
        {
            FileInfo fileInfo = new FileInfo(path);
            string[] sizePrefixes = { "Б", "КБ", "МБ", "ГБ" };
            int order = (int)Math.Floor(Math.Log(fileInfo.Length, 1024));
            double adjustedSize = Math.Round(fileInfo.Length / Math.Pow(1024, order), 2);

            titleLabel.Text = $"📄 {shortPath}";
            descLabel.Text = $"📌 Час створення: {fileInfo.CreationTime}\n" +
                            $"✏️ Остання зміна: {fileInfo.LastWriteTime}\n" +
                            $"📊 Розмір: {adjustedSize} {sizePrefixes[order]}\n" +
                            $"🔖 Розширення: {fileInfo.Extension}\n" +
                            $"🛡️ Атрибути: {fileInfo.Attributes}";

            try
            {
                pictureBoxPreview.Image = Image.FromFile(path);
                pictureBoxPreview.Visible = true;
                textBoxPreview.Visible = false;
            }
            catch
            {
                pictureBoxPreview.Visible = false;
                textBoxPreview.Visible = true;

                if (fileInfo.Length < 1048576)
                {
                    try
                    {
                        textBoxPreview.Text = File.ReadAllText(path);
                    }
                    catch
                    {
                        textBoxPreview.Text = "🔒 Неможливо прочитати файл";
                    }
                }
                else
                {
                    textBoxPreview.Text = "📁 Файл занадто великий для попереднього перегляду";
                }
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;

            string path = treeViewExplorer.SelectedNode.FullPath;
            string shortPath = Path.GetFileName(path);

            if (File.Exists(path))
            {
                UpdateFileInfo(path, shortPath);
            }
            else if (Directory.Exists(path))
            {
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                titleLabel.Text = $"📂 {shortPath}";
                descLabel.Text = $"📌 Час створення: {dirInfo.CreationTime}\n" +
                               $"✏️ Остання зміна: {dirInfo.LastWriteTime}\n" +
                               $"🛡️ Атрибути: {dirInfo.Attributes}\n" +
                               $"🗂️ Тип: Каталог";
            }
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            LoadDrives();
        }
    }
}