﻿using System.Windows.Forms;
using System.Drawing;

namespace Lab28_
{
    public static class InputBox
    {
        public static string Show(string prompt, string title, string defaultValue = "")
        {
            Form promptForm = new Form()
            {
                Width = 300,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = title,
                StartPosition = FormStartPosition.CenterParent,
                MaximizeBox = false,
                MinimizeBox = false
            };

            Label textLabel = new Label() { Left = 20, Top = 20, Text = prompt, AutoSize = true };
            textLabel.MaximumSize = new Size(promptForm.Width - 40, 0);
            textLabel.Size = textLabel.PreferredSize;

            TextBox inputBox = new TextBox() { Left = 20, Top = textLabel.Bottom + 10, Width = 250, Text = defaultValue };

            Button confirmation = new Button() { Text = "OK", Left = 110, Width = 75, Top = inputBox.Bottom + 15, DialogResult = DialogResult.OK };

            Button cancelButton = new Button() { Text = "Cancel", Left = 195, Width = 75, Top = inputBox.Bottom + 15, DialogResult = DialogResult.Cancel };

            promptForm.Controls.Add(confirmation);
            promptForm.Controls.Add(cancelButton);
            promptForm.Controls.Add(textLabel);
            promptForm.Controls.Add(inputBox);

            promptForm.AcceptButton = confirmation;
            promptForm.CancelButton = cancelButton;

            if (promptForm.ShowDialog() == DialogResult.OK)
            {
                return inputBox.Text;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}