﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab28_
{
    public partial class Form1 : Form
    {
        public List<string> checkedDirs = new List<string>();
        private string _clipboardPath = null;
        private string _clipboardOperationType = null;
        private const string _7zipExecutablePath = "C:\\Program Files\\7-Zip\\7z.exe";
        private Color defaultNodeColor = Color.FromArgb(240, 240, 240);
        private Color directoryColor = Color.FromArgb(220, 235, 255);
        private Color fileColor = Color.FromArgb(255, 240, 240);

        public Form1()
        {
            InitializeComponent();
            this.Font = new Font("Times New Roman", 14);
            this.BackColor = Color.FromArgb(250, 245, 255);
            LoadDrives();
        }

        private void LoadDrives()
        {
            treeViewExplorer.Nodes.Clear();
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
            {
                if (drive.IsReady)
                {
                    TreeNode node = treeViewExplorer.Nodes.Add(drive.Name);
                    node.Tag = "drive";
                    node.NodeFont = new Font("Times New Roman", 14, FontStyle.Bold);
                }
            }
        }

        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;

            string path = treeViewExplorer.SelectedNode.FullPath;
            string shortPath = Path.GetFileName(path);

            try
            {
                if (File.Exists(path))
                {
                    UpdateFileInfo(path, shortPath);
                    return;
                }

                if (!checkedDirs.Contains(path))
                {
                    checkedDirs.Add(path);
                    treeViewExplorer.SelectedNode.Nodes.Clear();

                    foreach (string dir in Directory.GetDirectories(path))
                    {
                        TreeNode child = treeViewExplorer.SelectedNode.Nodes.Add(Path.GetFileName(dir));
                        child.Tag = "folder";
                        child.NodeFont = new Font("Times New Roman", 14);
                        child.BackColor = directoryColor;
                    }

                    foreach (string file in Directory.GetFiles(path))
                    {
                        TreeNode child = treeViewExplorer.SelectedNode.Nodes.Add(Path.GetFileName(file));
                        child.Tag = "file";
                        child.NodeFont = new Font("Times New Roman", 14);
                        child.BackColor = fileColor;
                    }
                }
                treeViewExplorer.SelectedNode.Expand();
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Доступ заборонено до: " + path, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateFileInfo(string path, string shortPath)
        {
            FileInfo fileInfo = new FileInfo(path);
            string[] sizePrefixes = { "Б", "КБ", "МБ", "ГБ" };
            int order = (int)Math.Floor(Math.Log(fileInfo.Length, 1024));
            double adjustedSize = Math.Round(fileInfo.Length / Math.Pow(1024, order), 2);

            titleLabel.Text = $"📄 {shortPath}";
            descLabel.Text = $"📌 Час створення: {fileInfo.CreationTime}\n" +
                            $"✏️ Остання зміна: {fileInfo.LastWriteTime}\n" +
                            $"📊 Розмір: {adjustedSize} {sizePrefixes[order]}\n" +
                            $"🔖 Розширення: {fileInfo.Extension}\n" +
                            $"🛡️ Атрибути: {fileInfo.Attributes}";

            try
            {
                pictureBoxPreview.Image = Image.FromFile(path);
                pictureBoxPreview.Visible = true;
                textBoxPreview.Visible = false;
            }
            catch
            {
                pictureBoxPreview.Visible = false;
                textBoxPreview.Visible = true;

                if (fileInfo.Length < 1048576)
                {
                    try
                    {
                        textBoxPreview.Text = File.ReadAllText(path);
                    }
                    catch
                    {
                        textBoxPreview.Text = "🔒 Неможливо прочитати файл";
                    }
                }
                else
                {
                    textBoxPreview.Text = "📁 Файл занадто великий для попереднього перегляду";
                }
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;

            string path = treeViewExplorer.SelectedNode.FullPath;
            string shortPath = Path.GetFileName(path);

            if (File.Exists(path))
            {
                UpdateFileInfo(path, shortPath);
            }
            else if (Directory.Exists(path))
            {
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                titleLabel.Text = $"📂 {shortPath}";
                descLabel.Text = $"📌 Час створення: {dirInfo.CreationTime}\n" +
                               $"✏️ Остання зміна: {dirInfo.LastWriteTime}\n" +
                               $"🛡️ Атрибути: {dirInfo.Attributes}\n" +
                               $"🗂️ Тип: Каталог";
            }
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string path = treeViewExplorer.SelectedNode.FullPath;

            try
            {
                switch (e.ClickedItem.Name)
                {
                    case "deleteToolStripMenuItem":
                        HandleDelete(path);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка операції: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HandleDelete(string path)
        {
            DialogResult result = MessageBox.Show($"Ви впевнені, що хочете видалити \"{Path.GetFileName(path)}\"?", "Підтвердіть видалення", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                    treeViewExplorer.SelectedNode.Remove();
                    MessageBox.Show("Папку успішно видалено.", "Видалення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (File.Exists(path))
                {
                    File.Delete(path);
                    treeViewExplorer.SelectedNode.Remove();
                    MessageBox.Show("Файл успішно видалено.", "Видалення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Об'єкт не знайдено або вже видалено.", "Помилка видалення", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void createFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string currentPath = treeViewExplorer.SelectedNode.FullPath;

            if (File.Exists(currentPath))
            {
                MessageBox.Show("Виберіть папку для створення файлу.", "Невірна дія", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string fileName = InputBox.Show("Введіть ім'я нового файлу:", "Створити файл");
            if (string.IsNullOrWhiteSpace(fileName)) return;

            string newFilePath = Path.Combine(currentPath, fileName);

            try
            {
                if (File.Exists(newFilePath) || Directory.Exists(newFilePath))
                {
                    MessageBox.Show("Файл або папка з таким ім'ям вже існує.", "Помилка створення", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (File.Create(newFilePath)) { }
                TreeNode newFileNode = treeViewExplorer.SelectedNode.Nodes.Add(fileName);
                newFileNode.NodeFont = new Font("Times New Roman", 14, FontStyle.Regular);
                newFileNode.BackColor = fileColor;
                treeViewExplorer.SelectedNode.Expand();
                MessageBox.Show($"Файл '{fileName}' успішно створено.", "Створення файлу", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при створенні файлу: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void createFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string currentPath = treeViewExplorer.SelectedNode.FullPath;

            if (File.Exists(currentPath))
            {
                MessageBox.Show("Виберіть папку для створення нової папки.", "Невірна дія", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string folderName = InputBox.Show("Введіть ім'я нової папки:", "Створити папку");
            if (string.IsNullOrWhiteSpace(folderName)) return;

            string newFolderPath = Path.Combine(currentPath, folderName);

            try
            {
                if (File.Exists(newFolderPath) || Directory.Exists(newFolderPath))
                {
                    MessageBox.Show("Файл або папка з таким ім'ям вже існує.", "Помилка створення", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Directory.CreateDirectory(newFolderPath);
                TreeNode newFolderNode = treeViewExplorer.SelectedNode.Nodes.Add(folderName);
                newFolderNode.BackColor = directoryColor;
                newFolderNode.NodeFont = new Font("Times New Roman", 14, FontStyle.Bold);
                treeViewExplorer.SelectedNode.Expand();
                MessageBox.Show($"Папку '{folderName}' успішно створено.", "Створення папки", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при створенні папки: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void moveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string path = treeViewExplorer.SelectedNode.FullPath;

            if (!File.Exists(path) && !Directory.Exists(path))
            {
                MessageBox.Show("Об'єкт для вирізання не знайдено.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _clipboardPath = path;
            _clipboardOperationType = "cut";
            MessageBox.Show($"'{Path.GetFileName(path)}' вирізано. Ви можете вставити його в іншу папку.", "Вирізати", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string path = treeViewExplorer.SelectedNode.FullPath;

            if (!File.Exists(path) && !Directory.Exists(path))
            {
                MessageBox.Show("Об'єкт для копіювання не знайдено.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _clipboardPath = path;
            _clipboardOperationType = "copy";
            MessageBox.Show($"'{Path.GetFileName(path)}' скопійовано. Ви можете вставити його в іншу папку.", "Копіювати", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null)
            {
                MessageBox.Show("Виберіть папку, куди ви хочете вставити об'єкт.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_clipboardPath == null || _clipboardOperationType == null)
            {
                MessageBox.Show("Немає нічого для вставлення (буфер обміну порожній).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string destinationPath = treeViewExplorer.SelectedNode.FullPath;
            string sourceItemName = Path.GetFileName(_clipboardPath);
            string finalDestinationPath = Path.Combine(destinationPath, sourceItemName);

            if (File.Exists(destinationPath))
            {
                MessageBox.Show("Не можна вставити об'єкт у файл. Виберіть папку.", "Невірна дія", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (_clipboardOperationType == "cut")
                {
                    if (File.Exists(_clipboardPath))
                    {
                        File.Move(_clipboardPath, finalDestinationPath);
                    }
                    else if (Directory.Exists(_clipboardPath))
                    {
                        Directory.Move(_clipboardPath, finalDestinationPath);
                    }
                    MessageBox.Show($"'{sourceItemName}' успішно переміщено.", "Переміщення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (_clipboardOperationType == "copy")
                {
                    if (File.Exists(_clipboardPath))
                    {
                        File.Copy(_clipboardPath, finalDestinationPath, true);
                    }
                    else if (Directory.Exists(_clipboardPath))
                    {
                        CopyDirectory(_clipboardPath, finalDestinationPath);
                    }
                    MessageBox.Show($"'{sourceItemName}' успішно скопійовано.", "Копіювання", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                RefreshSelectedNodeContents();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при вставленні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                _clipboardPath = null;
                _clipboardOperationType = null;
            }
        }

        private void CopyDirectory(string sourceDir, string destinationDir)
        {
            Directory.CreateDirectory(destinationDir);

            foreach (var file in Directory.GetFiles(sourceDir))
            {
                string destFile = Path.Combine(destinationDir, Path.GetFileName(file));
                File.Copy(file, destFile, true);
            }

            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                string destSubDir = Path.Combine(destinationDir, Path.GetFileName(dir));
                CopyDirectory(dir, destSubDir);
            }
        }

        private void zipTo7zToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string itemPath = treeViewExplorer.SelectedNode.FullPath;

            if (!File.Exists(itemPath) && !Directory.Exists(itemPath))
            {
                MessageBox.Show("Будь ласка, виберіть файл або папку для архівування.", "Невірна дія", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string parentDirectory = Path.GetDirectoryName(itemPath);
            string itemName = Path.GetFileName(itemPath);
            string archiveName = InputBox.Show("Введіть ім'я архіву (без розширення .7z):", "Архівувати в .7z", itemName);
            if (string.IsNullOrWhiteSpace(archiveName)) return;

            string archivePath = Path.Combine(parentDirectory, archiveName + ".7z");

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = _7zipExecutablePath,
                    Arguments = $"a \"{archivePath}\" \"{itemPath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(psi))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                    {
                        MessageBox.Show($"'{itemName}' успішно заархівовано.", "Архівування", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshSelectedNodeContents();
                    }
                    else
                    {
                        MessageBox.Show($"Помилка архівування '{itemName}'", "Помилка архівування", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при архівуванні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void unzip7zToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string archivePath = treeViewExplorer.SelectedNode.FullPath;

            if (!File.Exists(archivePath) || !archivePath.EndsWith(".7z", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Будь ласка, виберіть файл архіву .7z для розпакування.", "Невірна дія", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string parentDirectory = Path.GetDirectoryName(archivePath);
            string defaultExtractFolderName = Path.GetFileNameWithoutExtension(archivePath);
            string extractFolderName = InputBox.Show("Введіть ім'я папки для розпакування:", "Розпакувати .7z", defaultExtractFolderName);
            if (string.IsNullOrWhiteSpace(extractFolderName)) return;

            string destinationDirectory = Path.Combine(parentDirectory, extractFolderName);

            try
            {
                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = _7zipExecutablePath,
                    Arguments = $"x \"{archivePath}\" -o\"{destinationDirectory}\" -y",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(psi))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                    {
                        MessageBox.Show($"Архів успішно розпаковано.", "Розпакування", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshSelectedNodeContents();
                    }
                    else
                    {
                        MessageBox.Show($"Помилка розпакування", "Помилка розпакування", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при розпакуванні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshSelectedNodeContents()
        {
            if (treeViewExplorer.SelectedNode == null) return;
            string selectedPath = treeViewExplorer.SelectedNode.FullPath;
            TreeNode parentNode = treeViewExplorer.SelectedNode.Parent;

            if (parentNode == null)
            {
                LoadDrives();
            }
            else
            {
                treeViewExplorer.SelectedNode.Nodes.Clear();
                if (checkedDirs.Contains(selectedPath))
                {
                    checkedDirs.Remove(selectedPath);
                }
                treeView1_DoubleClick(treeViewExplorer, new EventArgs());
            }
        }

        private TreeNode FindNodeByPath(TreeNodeCollection nodes, string path)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.FullPath.Equals(path, StringComparison.OrdinalIgnoreCase))
                {
                    return node;
                }

                TreeNode foundNode = FindNodeByPath(node.Nodes, path);
                if (foundNode != null)
                {
                    return foundNode;
                }
            }
            return null;
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            LoadDrives();
        }
    }
}