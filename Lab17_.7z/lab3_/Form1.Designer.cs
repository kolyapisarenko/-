﻿namespace lab3_
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnFazzyClear = new System.Windows.Forms.Button();
            this.lblFazzyDiv = new System.Windows.Forms.Label();
            this.lblFazzyMul = new System.Windows.Forms.Label();
            this.lblFazzySub = new System.Windows.Forms.Label();
            this.lblFazzySum = new System.Windows.Forms.Label();
            this.lblFazzyException = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFazzyResult = new System.Windows.Forms.Button();
            this.btnFazzySave = new System.Windows.Forms.Button();
            this.txtFazzySecondB = new System.Windows.Forms.TextBox();
            this.txtFazzySecondA = new System.Windows.Forms.TextBox();
            this.txtFazzyFirstB = new System.Windows.Forms.TextBox();
            this.txtFazzyFirstA = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblFractionClear = new System.Windows.Forms.Button();
            this.lblFractionDiv = new System.Windows.Forms.Label();
            this.lblFractionMul = new System.Windows.Forms.Label();
            this.lblFractionSub = new System.Windows.Forms.Label();
            this.lblFractionSum = new System.Windows.Forms.Label();
            this.lblFractionException = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lblFractionResult = new System.Windows.Forms.Button();
            this.btnFractionSave = new System.Windows.Forms.Button();
            this.txtFractionSecondDenominator = new System.Windows.Forms.TextBox();
            this.txtFractionSecondNumerator = new System.Windows.Forms.TextBox();
            this.txtFractionFirstDenominator = new System.Windows.Forms.TextBox();
            this.txtFractionFirstNumerator = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1198, 615);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1190, 583);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Умова";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lab3_.Properties.Resources._4;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1178, 118);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnFazzyClear);
            this.tabPage2.Controls.Add(this.lblFazzyDiv);
            this.tabPage2.Controls.Add(this.lblFazzyMul);
            this.tabPage2.Controls.Add(this.lblFazzySub);
            this.tabPage2.Controls.Add(this.lblFazzySum);
            this.tabPage2.Controls.Add(this.lblFazzyException);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnFazzyResult);
            this.tabPage2.Controls.Add(this.btnFazzySave);
            this.tabPage2.Controls.Add(this.txtFazzySecondB);
            this.tabPage2.Controls.Add(this.txtFazzySecondA);
            this.tabPage2.Controls.Add(this.txtFazzyFirstB);
            this.tabPage2.Controls.Add(this.txtFazzyFirstA);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1190, 583);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Нечіткі числа";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnFazzyClear
            // 
            this.btnFazzyClear.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFazzyClear.Location = new System.Drawing.Point(547, 202);
            this.btnFazzyClear.Name = "btnFazzyClear";
            this.btnFazzyClear.Size = new System.Drawing.Size(212, 46);
            this.btnFazzyClear.TabIndex = 22;
            this.btnFazzyClear.Text = "Очистити поля";
            this.btnFazzyClear.UseVisualStyleBackColor = true;
            this.btnFazzyClear.Click += new System.EventHandler(this.btnFazzyClear_Click);
            // 
            // lblFazzyDiv
            // 
            this.lblFazzyDiv.AutoSize = true;
            this.lblFazzyDiv.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFazzyDiv.Location = new System.Drawing.Point(301, 478);
            this.lblFazzyDiv.Name = "lblFazzyDiv";
            this.lblFazzyDiv.Size = new System.Drawing.Size(0, 26);
            this.lblFazzyDiv.TabIndex = 21;
            // 
            // lblFazzyMul
            // 
            this.lblFazzyMul.AutoSize = true;
            this.lblFazzyMul.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFazzyMul.Location = new System.Drawing.Point(301, 426);
            this.lblFazzyMul.Name = "lblFazzyMul";
            this.lblFazzyMul.Size = new System.Drawing.Size(0, 26);
            this.lblFazzyMul.TabIndex = 20;
            // 
            // lblFazzySub
            // 
            this.lblFazzySub.AutoSize = true;
            this.lblFazzySub.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFazzySub.Location = new System.Drawing.Point(301, 370);
            this.lblFazzySub.Name = "lblFazzySub";
            this.lblFazzySub.Size = new System.Drawing.Size(0, 26);
            this.lblFazzySub.TabIndex = 19;
            // 
            // lblFazzySum
            // 
            this.lblFazzySum.AutoSize = true;
            this.lblFazzySum.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFazzySum.Location = new System.Drawing.Point(301, 316);
            this.lblFazzySum.Name = "lblFazzySum";
            this.lblFazzySum.Size = new System.Drawing.Size(0, 26);
            this.lblFazzySum.TabIndex = 18;
            // 
            // lblFazzyException
            // 
            this.lblFazzyException.AutoSize = true;
            this.lblFazzyException.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFazzyException.ForeColor = System.Drawing.Color.Red;
            this.lblFazzyException.Location = new System.Drawing.Point(79, 534);
            this.lblFazzyException.Name = "lblFazzyException";
            this.lblFazzyException.Size = new System.Drawing.Size(0, 26);
            this.lblFazzyException.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(79, 478);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 26);
            this.label11.TabIndex = 16;
            this.label11.Text = "Частка";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(79, 426);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 26);
            this.label10.TabIndex = 15;
            this.label10.Text = "Добуток";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(79, 370);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 26);
            this.label9.TabIndex = 14;
            this.label9.Text = "Різниця";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(79, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 26);
            this.label8.TabIndex = 13;
            this.label8.Text = "Сума";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(104, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(344, 26);
            this.label7.TabIndex = 12;
            this.label7.Text = "Результат арифметичних операцій";
            // 
            // btnFazzyResult
            // 
            this.btnFazzyResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFazzyResult.Location = new System.Drawing.Point(258, 202);
            this.btnFazzyResult.Name = "btnFazzyResult";
            this.btnFazzyResult.Size = new System.Drawing.Size(246, 46);
            this.btnFazzyResult.TabIndex = 11;
            this.btnFazzyResult.Text = "Обчислити значення";
            this.btnFazzyResult.UseVisualStyleBackColor = true;
            this.btnFazzyResult.Click += new System.EventHandler(this.btnFazzyResult_Click);
            // 
            // btnFazzySave
            // 
            this.btnFazzySave.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFazzySave.Location = new System.Drawing.Point(41, 202);
            this.btnFazzySave.Name = "btnFazzySave";
            this.btnFazzySave.Size = new System.Drawing.Size(183, 46);
            this.btnFazzySave.TabIndex = 10;
            this.btnFazzySave.Text = "Зберегти числа";
            this.btnFazzySave.UseVisualStyleBackColor = true;
            this.btnFazzySave.Click += new System.EventHandler(this.btnFazzySave_Click);
            // 
            // txtFazzySecondB
            // 
            this.txtFazzySecondB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFazzySecondB.Location = new System.Drawing.Point(759, 141);
            this.txtFazzySecondB.Name = "txtFazzySecondB";
            this.txtFazzySecondB.Size = new System.Drawing.Size(100, 34);
            this.txtFazzySecondB.TabIndex = 9;
            // 
            // txtFazzySecondA
            // 
            this.txtFazzySecondA.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFazzySecondA.Location = new System.Drawing.Point(759, 79);
            this.txtFazzySecondA.Name = "txtFazzySecondA";
            this.txtFazzySecondA.Size = new System.Drawing.Size(100, 34);
            this.txtFazzySecondA.TabIndex = 8;
            // 
            // txtFazzyFirstB
            // 
            this.txtFazzyFirstB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFazzyFirstB.Location = new System.Drawing.Point(280, 136);
            this.txtFazzyFirstB.Name = "txtFazzyFirstB";
            this.txtFazzyFirstB.Size = new System.Drawing.Size(100, 34);
            this.txtFazzyFirstB.TabIndex = 7;
            // 
            // txtFazzyFirstA
            // 
            this.txtFazzyFirstA.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFazzyFirstA.Location = new System.Drawing.Point(280, 79);
            this.txtFazzyFirstA.Name = "txtFazzyFirstA";
            this.txtFazzyFirstA.Size = new System.Drawing.Size(100, 34);
            this.txtFazzyFirstA.TabIndex = 6;
            this.txtFazzyFirstA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFazzy_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(514, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "Введіть друге число";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(514, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(216, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "Введіть перше число";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(36, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Введіть друге число";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(36, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Введіть перше число";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(514, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Друга пара чисел";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(36, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Перша пара чисел";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblFractionClear);
            this.tabPage3.Controls.Add(this.lblFractionDiv);
            this.tabPage3.Controls.Add(this.lblFractionMul);
            this.tabPage3.Controls.Add(this.lblFractionSub);
            this.tabPage3.Controls.Add(this.lblFractionSum);
            this.tabPage3.Controls.Add(this.lblFractionException);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.lblFractionResult);
            this.tabPage3.Controls.Add(this.btnFractionSave);
            this.tabPage3.Controls.Add(this.txtFractionSecondDenominator);
            this.tabPage3.Controls.Add(this.txtFractionSecondNumerator);
            this.tabPage3.Controls.Add(this.txtFractionFirstDenominator);
            this.tabPage3.Controls.Add(this.txtFractionFirstNumerator);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1190, 583);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Дроби";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblFractionClear
            // 
            this.lblFractionClear.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionClear.Location = new System.Drawing.Point(644, 198);
            this.lblFractionClear.Name = "lblFractionClear";
            this.lblFractionClear.Size = new System.Drawing.Size(194, 51);
            this.lblFractionClear.TabIndex = 45;
            this.lblFractionClear.Text = "Очистити поля";
            this.lblFractionClear.UseVisualStyleBackColor = true;
            this.lblFractionClear.Click += new System.EventHandler(this.lblFractionClear_Click);
            // 
            // lblFractionDiv
            // 
            this.lblFractionDiv.AutoSize = true;
            this.lblFractionDiv.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionDiv.Location = new System.Drawing.Point(247, 474);
            this.lblFractionDiv.Name = "lblFractionDiv";
            this.lblFractionDiv.Size = new System.Drawing.Size(0, 26);
            this.lblFractionDiv.TabIndex = 44;
            // 
            // lblFractionMul
            // 
            this.lblFractionMul.AutoSize = true;
            this.lblFractionMul.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionMul.Location = new System.Drawing.Point(247, 422);
            this.lblFractionMul.Name = "lblFractionMul";
            this.lblFractionMul.Size = new System.Drawing.Size(0, 26);
            this.lblFractionMul.TabIndex = 43;
            // 
            // lblFractionSub
            // 
            this.lblFractionSub.AutoSize = true;
            this.lblFractionSub.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionSub.Location = new System.Drawing.Point(247, 366);
            this.lblFractionSub.Name = "lblFractionSub";
            this.lblFractionSub.Size = new System.Drawing.Size(0, 26);
            this.lblFractionSub.TabIndex = 42;
            // 
            // lblFractionSum
            // 
            this.lblFractionSum.AutoSize = true;
            this.lblFractionSum.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionSum.Location = new System.Drawing.Point(247, 312);
            this.lblFractionSum.Name = "lblFractionSum";
            this.lblFractionSum.Size = new System.Drawing.Size(0, 26);
            this.lblFractionSum.TabIndex = 41;
            // 
            // lblFractionException
            // 
            this.lblFractionException.AutoSize = true;
            this.lblFractionException.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionException.ForeColor = System.Drawing.Color.Red;
            this.lblFractionException.Location = new System.Drawing.Point(33, 530);
            this.lblFractionException.Name = "lblFractionException";
            this.lblFractionException.Size = new System.Drawing.Size(0, 26);
            this.lblFractionException.TabIndex = 40;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(33, 474);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 26);
            this.label22.TabIndex = 39;
            this.label22.Text = "Частка";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(33, 422);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(95, 26);
            this.label23.TabIndex = 38;
            this.label23.Text = "Добуток";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(33, 366);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(87, 26);
            this.label24.TabIndex = 37;
            this.label24.Text = "Різниця";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(33, 312);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 26);
            this.label25.TabIndex = 36;
            this.label25.Text = "Сума";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(76, 266);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(356, 26);
            this.label26.TabIndex = 35;
            this.label26.Text = "Результати арифметичних операцій";
            // 
            // lblFractionResult
            // 
            this.lblFractionResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFractionResult.Location = new System.Drawing.Point(298, 198);
            this.lblFractionResult.Name = "lblFractionResult";
            this.lblFractionResult.Size = new System.Drawing.Size(258, 51);
            this.lblFractionResult.TabIndex = 34;
            this.lblFractionResult.Text = "Обчислити результати";
            this.lblFractionResult.UseVisualStyleBackColor = true;
            this.lblFractionResult.Click += new System.EventHandler(this.lblFractionResult_Click);
            // 
            // btnFractionSave
            // 
            this.btnFractionSave.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFractionSave.Location = new System.Drawing.Point(38, 198);
            this.btnFractionSave.Name = "btnFractionSave";
            this.btnFractionSave.Size = new System.Drawing.Size(176, 51);
            this.btnFractionSave.TabIndex = 33;
            this.btnFractionSave.Text = "Зберегти дроби";
            this.btnFractionSave.UseVisualStyleBackColor = true;
            this.btnFractionSave.Click += new System.EventHandler(this.btnFractionSave_Click);
            // 
            // txtFractionSecondDenominator
            // 
            this.txtFractionSecondDenominator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFractionSecondDenominator.Location = new System.Drawing.Point(881, 137);
            this.txtFractionSecondDenominator.Name = "txtFractionSecondDenominator";
            this.txtFractionSecondDenominator.Size = new System.Drawing.Size(100, 34);
            this.txtFractionSecondDenominator.TabIndex = 32;
            // 
            // txtFractionSecondNumerator
            // 
            this.txtFractionSecondNumerator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFractionSecondNumerator.Location = new System.Drawing.Point(881, 75);
            this.txtFractionSecondNumerator.Name = "txtFractionSecondNumerator";
            this.txtFractionSecondNumerator.Size = new System.Drawing.Size(100, 34);
            this.txtFractionSecondNumerator.TabIndex = 31;
            this.txtFractionSecondNumerator.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFractionNumerator_KeyPress);
            // 
            // txtFractionFirstDenominator
            // 
            this.txtFractionFirstDenominator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFractionFirstDenominator.Location = new System.Drawing.Point(252, 132);
            this.txtFractionFirstDenominator.Name = "txtFractionFirstDenominator";
            this.txtFractionFirstDenominator.Size = new System.Drawing.Size(100, 34);
            this.txtFractionFirstDenominator.TabIndex = 30;
            this.txtFractionFirstDenominator.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFractionDenominator_KeyPress);
            // 
            // txtFractionFirstNumerator
            // 
            this.txtFractionFirstNumerator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtFractionFirstNumerator.Location = new System.Drawing.Point(252, 75);
            this.txtFractionFirstNumerator.Name = "txtFractionFirstNumerator";
            this.txtFractionFirstNumerator.Size = new System.Drawing.Size(100, 34);
            this.txtFractionFirstNumerator.TabIndex = 29;
            this.txtFractionFirstNumerator.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFractionNumerator_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(639, 140);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(194, 26);
            this.label27.TabIndex = 28;
            this.label27.Text = "Введіть знаменник";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(639, 83);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(191, 26);
            this.label28.TabIndex = 27;
            this.label28.Text = "Введіть чисельник";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(33, 140);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(194, 26);
            this.label29.TabIndex = 26;
            this.label29.Text = "Введіть знаменник";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(33, 83);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(191, 26);
            this.label30.TabIndex = 25;
            this.label30.Text = "Введіть чисельник";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(639, 27);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(132, 26);
            this.label31.TabIndex = 24;
            this.label31.Text = "Другий дріб";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(33, 27);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(139, 26);
            this.label32.TabIndex = 23;
            this.label32.Text = "Перший дріб";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 639);
            this.Controls.Add(this.tabControl1);
            this.Name = "mainForm";
            this.Text = "Lab3_";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFazzySecondB;
        private System.Windows.Forms.TextBox txtFazzySecondA;
        private System.Windows.Forms.TextBox txtFazzyFirstB;
        private System.Windows.Forms.TextBox txtFazzyFirstA;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFazzyException;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFazzyResult;
        private System.Windows.Forms.Button btnFazzySave;
        private System.Windows.Forms.Button btnFazzyClear;
        private System.Windows.Forms.Label lblFazzyDiv;
        private System.Windows.Forms.Label lblFazzyMul;
        private System.Windows.Forms.Label lblFazzySub;
        private System.Windows.Forms.Label lblFazzySum;
        private System.Windows.Forms.Button lblFractionClear;
        private System.Windows.Forms.Label lblFractionDiv;
        private System.Windows.Forms.Label lblFractionMul;
        private System.Windows.Forms.Label lblFractionSub;
        private System.Windows.Forms.Label lblFractionSum;
        private System.Windows.Forms.Label lblFractionException;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button lblFractionResult;
        private System.Windows.Forms.Button btnFractionSave;
        private System.Windows.Forms.TextBox txtFractionSecondDenominator;
        private System.Windows.Forms.TextBox txtFractionSecondNumerator;
        private System.Windows.Forms.TextBox txtFractionFirstDenominator;
        private System.Windows.Forms.TextBox txtFractionFirstNumerator;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
    }
}

