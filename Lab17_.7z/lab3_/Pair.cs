﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_
{
    abstract class Pair
    {
        protected double a;
        protected double b;
        public double A { 
            get { return a; } 
            set { a = value; } 
        }
        public double B { 
            get { return b; } 
            set { b = value; } 
        }
        protected Pair()
        {
            A = 1;
            B = 2;
        }
        protected Pair(double x, double y)
        {
            A = x;
            B = y;
        }
        public abstract Pair Sum(Pair other);
        public abstract Pair Sub(Pair other);
        public abstract Pair Mul(Pair other);
        public abstract Pair Div(Pair other);
        public static Pair operator+(Pair a, Pair b)
        {
            return a.Sum(b);
        }
        public static Pair operator-(Pair a, Pair b)
        {
            return a.Sub(b);
        }
        public static Pair operator*(Pair a, Pair b)
        {
            return a.Mul(b);
        }
        public static Pair operator/(Pair a, Pair b)
        {
            return a.Div(b);
        }
    }
}
