﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace lab3_
{
    class Fraction:Pair
    {
        public Fraction() : base() { }
        public Fraction(double x, double y) : base(x, y) { 
            if(y == 0)
            {
                throw new DivideByZeroException("Знаменник не може бути нулем!");
            }
            if (y < 0)
            {
                x *= -1; 
                y *= -1;
            }
        }
        public void Normalization() { 
            if (B < 0)
            {
                A = -A;
                B = -B;
            }
        }
        private int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        public override Pair Sum(Pair other)
        {
            int b = (int)(this.B * other.B);
            int a = (int)((this.A * other.B) + (other.A * this.B));
            int c = GCD(a, b);
            a /= c;
            b /= c;
            return new Fraction(a, b);
        }
        public override Pair Sub(Pair other)
        {
            int b = (int)(this.B * other.B);
            int a = (int)((this.A * other.B) - (other.A * this.B));
            int c = GCD(a, b);
            a /= c;
            b /= c;
            return new Fraction(a, b);
        }
        public override Pair Mul(Pair other)
        {
            int b = (int)(this.B * other.B);
            int a = (int)((this.A * other.A));
            int c = GCD(a, b);
            a /= c;
            b /= c;
            return new Fraction(a, b);
        }
        public override Pair Div(Pair other)
        {
            if(other.A == 0)
            {
                throw new DivideByZeroException("Ділення на нуль!");
            }
            int b = (int)(this.B * other.A);
            int a = (int)((this.A * other.B));
            if (b < 0)
            {
                a *= -1;
                b *= -1;
            }
            int c = GCD(a, b);
            a /= c;
            b /= c;
            return new Fraction(a, b);
        }
        public override string ToString()
        {
            if(A == B)
            {
                return "1";
            }
            else if (A % B == 0)
            {
                int n = (int)(A / B);
                return n.ToString();
            }
            else if (A == 0)
            {
                return "0";
            }
            else
            {
                return $"{A}/{B}";
            }
        }
    }
}
