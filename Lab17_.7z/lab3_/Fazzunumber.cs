﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_
{
    class Fazzunumber:Pair
    {
        public Fazzunumber() : base() { }
        public Fazzunumber(double x, double y) : base(x, y) { }
        public override Pair Sum(Pair other)
        {
            return new Fazzunumber(this.A + other.A, this.B + other.B);
        }
        public override Pair Sub(Pair other)
        {
            return new Fazzunumber(this.A - other.A, this.B - other.B);
        }
        public override Pair Mul(Pair other)
        {
            return new Fazzunumber(this.A * other.A, this.B * other.B);
        }
        public override Pair Div(Pair other)
        {
            if(other.A == 0 || other.B == 0)
            {
                throw new DivideByZeroException("Ділення на нуль!");
            }
            return new Fazzunumber(this.A / other.A, this.B / other.B);
        }
        public override string ToString()
        {
            return $"({A}, {B})";
        }
    }
}
