﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab3_
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }
        Fazzunumber faz1, faz2;
        Fraction f1, f2;

        //Арифметичні операції нечітких чисел
        private void btnFazzyResult_Click(object sender, EventArgs e)
        {
            try
            {
                lblFazzyException.Text = "";
                Fazzunumber sum, sub, mul, div;
                if(faz1 == null)
                {
                    faz1 = new Fazzunumber();
                }
                if(faz2 == null)
                {
                    faz2 = new Fazzunumber();
                }
                sum = (Fazzunumber)(faz1 + faz2);
                sub = (Fazzunumber)(faz1 - faz2);
                mul = (Fazzunumber)(faz1 * faz2);
                div = (Fazzunumber)(faz1 / faz2);
                lblFazzySum.Text = sum.ToString();
                lblFazzySub.Text = sub.ToString();
                lblFazzyMul.Text = mul.ToString();
                lblFazzyDiv.Text = div.ToString();
            }
            catch(DivideByZeroException ex)
            {
                lblFazzyException.Text = ex.Message;
            }
        }

        //Обмеження текстових полів нечітких чисел
        private void txtFazzy_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }
            if (e.KeyChar == '.')
            {
                if (textBox.Text.IndexOf('.') != -1)
                {
                    e.Handled = true;
                }
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnFazzySave.Focus();
                }
                return;
            }
            e.Handled = true;
        }

        //Очищення полів дробів
        private void lblFractionClear_Click(object sender, EventArgs e)
        {
            txtFractionFirstNumerator.Clear();
            txtFractionFirstDenominator.Clear();
            txtFractionSecondNumerator.Clear();
            txtFractionSecondDenominator.Clear();
        }

        //Збереження дробів
        private void btnFractionSave_Click(object sender, EventArgs e)
        {
            try
            {
                lblFractionException.Text = "";
                double a1, b1, a2, b2;
                a1 = Convert.ToDouble(txtFractionFirstNumerator.Text);
                b1 = Convert.ToDouble(txtFractionFirstDenominator.Text);
                a2 = Convert.ToDouble(txtFractionSecondNumerator.Text);
                b2 = Convert.ToDouble(txtFractionSecondDenominator.Text);
                f1 = new Fraction(a1, b1);
                f2 = new Fraction(a2, b2);
            }
            catch (DivideByZeroException ex)
            {
                lblFractionException.Text = ex.Message;
            }
            catch
            {
                if (txtFractionFirstNumerator.Text.Length == 0)
                {
                    txtFractionFirstNumerator.Focus();
                }
                else if (txtFractionFirstDenominator.Text.Length == 0)
                {
                    txtFractionFirstDenominator.Focus();
                }
                else if (txtFractionSecondNumerator.Text.Length == 0)
                {
                    txtFractionSecondNumerator.Focus();
                }
                else
                {
                    txtFractionSecondDenominator.Focus();
                }
            }
        }

        //Арифметичні операції дробів
        private void lblFractionResult_Click(object sender, EventArgs e)
        {
            try
            {
                lblFractionException.Text = "";
                Fraction sum, sub, mul, div;
                if (f1 == null)
                {
                    f1 = new Fraction();
                }
                if (f2 == null)
                {
                    f2 = new Fraction();
                }
                sum = (Fraction)(f1 + f2);
                sum.Normalization();
                sub = (Fraction)(f1 - f2);
                sub.Normalization();
                mul = (Fraction)(f1 * f2);
                mul.Normalization();
                div = (Fraction)(f1 / f2);
                div.Normalization();
                lblFractionSum.Text = sum.ToString();
                lblFractionSub.Text = sub.ToString();
                lblFractionMul.Text = mul.ToString();
                lblFractionDiv.Text = div.ToString();
            }
            catch (DivideByZeroException ex)
            {
                lblFazzyException.Text = ex.Message;
            }
        }

        //Обмеження чисельника
        private void txtFractionNumerator_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnFractionSave.Focus();
                }
                return;
            }
            e.Handled = true;
        }

        //Обмеження знаменника
        private void txtFractionDenominator_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnFractionSave.Focus();
                }
                return;
            }
            e.Handled = true;
        }

        //Очищення полів нечітких чисел
        private void btnFazzyClear_Click(object sender, EventArgs e)
        {
            txtFazzyFirstA.Clear();
            txtFazzyFirstB.Clear();
            txtFazzySecondA.Clear();
            txtFazzySecondB.Clear();
        }

        //Задання нечітких чисел
        private void btnFazzySave_Click(object sender, EventArgs e)
        {
            try
            {
                double a1, b1, a2, b2;
                a1 = Convert.ToDouble(txtFazzyFirstA.Text);
                b1 = Convert.ToDouble(txtFazzyFirstB.Text);
                a2 = Convert.ToDouble(txtFazzySecondA.Text);
                b2 = Convert.ToDouble(txtFazzySecondB.Text);
                faz1 = new Fazzunumber(a1, b1);
                faz2 = new Fazzunumber(a2, b2);
            }
            catch
            {
                if(txtFazzyFirstA.Text.Length == 0) {
                    txtFazzyFirstA.Focus();
                }
                else if (txtFazzyFirstB.Text.Length == 0)
                {
                    txtFazzyFirstB.Focus();
                }
                else if (txtFazzySecondA.Text.Length == 0)
                {
                    txtFazzySecondA.Focus();
                }
                else
                {
                    txtFazzySecondB.Focus();
                }
            }
        }
    }
}
