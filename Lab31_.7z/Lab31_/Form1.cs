﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Lab31_
{
    public partial class Form1 : Form
    {
        public BindingList<ProcessInfo> Processes { get; set; } = new BindingList<ProcessInfo>();

        public Form1()
        {
            InitializeComponent();
            dataGridView1.DataSource = Processes;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshProcessList();
        }

        private void RefreshProcessList()
        {
            Processes.Clear();
            foreach (var process in Process.GetProcesses())
            {
                try
                {
                    Processes.Add(new ProcessInfo
                    {
                        Id = process.Id,
                        ProcessName = process.ProcessName,
                        StartTime = process.StartTime.ToString(),
                        MemoryMB = (process.WorkingSet64 / 1024.0 / 1024.0).ToString("F2")
                    });
                }
                catch { }
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            RefreshProcessList();
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, "processes.txt");
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    foreach (var process in Processes)
                    {
                        sw.WriteLine($"ID {process.Id}, Name {process.ProcessName}, Start {process.StartTime}, Memory {process.MemoryMB} MB");
                    }
                    MessageBox.Show("Процеси експортовано до processes.txt на робочому столі", "Експорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка експорту {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void StartProcessButton_Click(object sender, EventArgs e)
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Process.Start(dialog.FileName);
                    MessageBox.Show("Процес запущено", "Успішно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshProcessList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не вдалося запустити процес {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ProcessesGrid_RightClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                dataGridView1.Rows[e.RowIndex].Selected = true;
                contextMenuStrip1.Show(dataGridView1, e.Location);
            }
        }

        private void InfoMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var info = (ProcessInfo)dataGridView1.SelectedRows[0].DataBoundItem;
                try
                {
                    var process = Process.GetProcessById(info.Id);
                    string message = $"Id {process.Id}\nІм'я {process.ProcessName}\nЧас початку {process.StartTime}\nПам'ять {(process.WorkingSet64 / 1024.0 / 1024.0).ToString("F2")} МБ";
                    MessageBox.Show(message, "Інформація про процес", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не вдалося отримати інформацію про процес {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void KillMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var info = (ProcessInfo)dataGridView1.SelectedRows[0].DataBoundItem;
                try
                {
                    var process = Process.GetProcessById(info.Id);
                    process.Kill();
                    RefreshProcessList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не вдалося завершити процес {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ThreadsModulesMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var info = (ProcessInfo)dataGridView1.SelectedRows[0].DataBoundItem;
                try
                {
                    var process = Process.GetProcessById(info.Id);
                    var threads = process.Threads;
                    var modules = process.Modules;

                    string result = "ПОТОКИ\n";
                    foreach (ProcessThread thread in threads)
                        result += $"Thread ID {thread.Id}, Priority {thread.PriorityLevel}\n";

                    result += "\nМОДУЛІ\n";
                    foreach (ProcessModule module in modules)
                        result += $"{module.ModuleName} - {module.FileName}\n";

                    MessageBox.Show(result, "Потоки та модулі", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не вдалося отримати потоки/модулі {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

    public class ProcessInfo
    {
        public int Id { get; set; }
        public string ProcessName { get; set; }
        public string StartTime { get; set; }
        public string MemoryMB { get; set; }
    }
}