﻿using System.IO;
using System.Xml.Serialization;

namespace Lab30_
{
    public class FtpClientSettings
    {
        public string Host { get; set; } = "ftp.example.com";
        public string Username { get; set; } = "user";
        public string Password { get; set; } = "password";
        public string LocalFolder { get; set; } = "";
        public string RemoteFolder { get; set; } = "/";
        public bool PassiveMode { get; set; } = true;

        private static readonly string SettingsFile = "ftp_settings.xml";

        public static FtpClientSettings Load()
        {
            if (File.Exists(SettingsFile))
            {
                var serializer = new XmlSerializer(typeof(FtpClientSettings));
                using (var reader = new StreamReader(SettingsFile))
                {
                    return (FtpClientSettings)serializer.Deserialize(reader);
                }
            }
            return new FtpClientSettings();
        }

        public void Save()
        {
            var serializer = new XmlSerializer(typeof(FtpClientSettings));
            using (var writer = new StreamWriter(SettingsFile))
            {
                serializer.Serialize(writer, this);
            }
        }
    }
}