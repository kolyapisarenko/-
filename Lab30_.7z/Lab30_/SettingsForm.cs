﻿using System;
using System.Windows.Forms;

namespace Lab30_
{
    public partial class SettingsForm : Form
    {
        private readonly FtpClientSettings settings;

        public SettingsForm(FtpClientSettings settings)
        {
            InitializeComponent();
            this.settings = settings;
            LoadSettings();
        }

        private void LoadSettings()
        {
            txtHost.Text = settings.Host;
            txtUsername.Text = settings.Username;
            txtPassword.Text = settings.Password;
            txtLocalFolder.Text = settings.LocalFolder;
            txtRemoteFolder.Text = settings.RemoteFolder;
            chkPassiveMode.Checked = settings.PassiveMode;
        }

        private void SaveSettings()
        {
            settings.Host = txtHost.Text;
            settings.Username = txtUsername.Text;
            settings.Password = txtPassword.Text;
            settings.LocalFolder = txtLocalFolder.Text;
            settings.RemoteFolder = txtRemoteFolder.Text;
            settings.PassiveMode = chkPassiveMode.Checked;
        }

        private void btnBrowseLocal_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtLocalFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            SaveSettings();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}