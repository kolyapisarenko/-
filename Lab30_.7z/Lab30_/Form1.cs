﻿using System;
using System.IO;
using System.Net;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;

namespace Lab30_
{
    public partial class MainForm : Form
    {
        private FtpClientSettings settings;
        private string currentDirectory = "/";
        private bool isConnected = false;
        private string selectedFile = "";
        private bool passiveMode = true;

        public MainForm()
        {
            InitializeComponent();
            LoadSettings();
            UpdateControls();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            txtHost.Text = settings.Host;
            txtUsername.Text = settings.Username;
            txtPassword.Text = settings.Password;
            passiveModeToolStripMenuItem.Checked = settings.PassiveMode;
            detailsToolStripMenuItem.PerformClick();
        }

        private void LoadSettings()
        {
            settings = FtpClientSettings.Load();
        }

        private void SaveSettings()
        {
            settings.Host = txtHost.Text;
            settings.Username = txtUsername.Text;
            settings.Password = txtPassword.Text;
            settings.PassiveMode = passiveMode;
            settings.Save();
        }

        private void UpdateControls()
        {
            btnConnect.Enabled = !isConnected;
            btnDisconnect.Enabled = isConnected;
            btnSettings.Enabled = !isConnected;

            btnCreateDir.Enabled = isConnected;
            btnRename.Enabled = isConnected && !string.IsNullOrEmpty(selectedFile);
            btnDelete.Enabled = isConnected && !string.IsNullOrEmpty(selectedFile);
            btnUpload.Enabled = isConnected;
            btnUploadFolder.Enabled = isConnected;
            btnDownload.Enabled = isConnected && !string.IsNullOrEmpty(selectedFile);
            btnRefresh.Enabled = isConnected;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                SaveSettings();
                passiveMode = passiveModeToolStripMenuItem.Checked;

                if (string.IsNullOrWhiteSpace(txtHost.Text) || string.IsNullOrWhiteSpace(txtUsername.Text))
                {
                    MessageBox.Show("Введіть адресу сервера та ім'я користувача", "Помилка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                ListDirectoryDetails("/");

                isConnected = true;
                lblStatus.Text = "Підключено до " + txtHost.Text;
                UpdateControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення: " + ex.Message, "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            isConnected = false;
            lblStatus.Text = "Відключено";
            treeView1.Nodes.Clear();
            listView1.Items.Clear();
            UpdateControls();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (isConnected)
            {
                ListDirectoryDetails(currentDirectory);
            }
        }

        private void ListDirectoryDetails(string directory)
        {
            try
            {
                treeView1.BeginUpdate();
                listView1.BeginUpdate();

                treeView1.Nodes.Clear();
                listView1.Items.Clear();

                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + directory);
                request.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
                request.UsePassive = passiveMode;

                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                using (Stream responseStream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(responseStream))
                {
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        bool isDirectory = line.StartsWith("d");
                        string[] parts = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string name = parts[parts.Length - 1];
                        string size = isDirectory ? "" : parts[4];
                        string date = parts[5] + " " + parts[6] + " " + parts[7];

                        if (isDirectory)
                        {
                            TreeNode node = new TreeNode(name);
                            node.ImageIndex = 1;
                            node.SelectedImageIndex = 1;
                            node.Tag = directory + name + "/";
                            treeView1.Nodes.Add(node);
                        }

                        ListViewItem item = new ListViewItem(name);
                        item.SubItems.Add(isDirectory ? "Папка" : "Файл");
                        item.SubItems.Add(size);
                        item.SubItems.Add(date);
                        item.ImageIndex = isDirectory ? 1 : 2;
                        listView1.Items.Add(item);

                        line = reader.ReadLine();
                    }
                }

                currentDirectory = directory;
                lblStatus.Text = "Поточний каталог: " + currentDirectory;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка отримання списку файлів: " + ex.Message, "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                treeView1.EndUpdate();
                listView1.EndUpdate();
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (isConnected && e.Node != null)
            {
                ListDirectoryDetails(e.Node.Tag.ToString());
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                ListViewItem item = listView1.SelectedItems[0];
                if (item.SubItems[1].Text == "Папка")
                {
                    string newDir = currentDirectory + item.Text + "/";
                    ListDirectoryDetails(newDir);
                }
                else
                {
                    selectedFile = item.Text;
                    UpdateControls();
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                selectedFile = listView1.SelectedItems[0].Text;
            }
            else
            {
                selectedFile = "";
            }
            UpdateControls();
        }

        private void btnCreateDir_Click(object sender, EventArgs e)
        {
            string dirName = Microsoft.VisualBasic.Interaction.InputBox("Введіть ім'я нової папки:", "Створити папку", "");
            if (!string.IsNullOrWhiteSpace(dirName))
            {
                try
                {
                    FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + currentDirectory + dirName);
                    request.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                    request.Method = WebRequestMethods.Ftp.MakeDirectory;
                    request.UsePassive = passiveMode;

                    using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                    {
                        MessageBox.Show("Папка успішно створена", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ListDirectoryDetails(currentDirectory);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка створення папки: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRename_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                string oldName = listView1.SelectedItems[0].Text;
                string newName = Microsoft.VisualBasic.Interaction.InputBox("Введіть нове ім'я:", "Перейменувати", oldName);
                if (!string.IsNullOrWhiteSpace(newName) && newName != oldName)
                {
                    try
                    {
                        FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + currentDirectory + oldName);
                        request.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                        request.Method = WebRequestMethods.Ftp.Rename;
                        request.RenameTo = newName;
                        request.UsePassive = passiveMode;

                        using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                        {
                            MessageBox.Show("Файл/папка успішно перейменовані", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ListDirectoryDetails(currentDirectory);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Помилка перейменування: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                string fileName = listView1.SelectedItems[0].Text;
                bool isDirectory = listView1.SelectedItems[0].SubItems[1].Text == "Папка";

                if (MessageBox.Show($"Ви впевнені, що хочете видалити {(isDirectory ? "папку" : "файл")} '{fileName}'?",
                    "Підтвердження", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + currentDirectory + fileName);
                        request.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                        request.Method = isDirectory ? WebRequestMethods.Ftp.RemoveDirectory : WebRequestMethods.Ftp.DeleteFile;
                        request.UsePassive = passiveMode;

                        using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                        {
                            MessageBox.Show($"{fileName} успішно видалено", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ListDirectoryDetails(currentDirectory);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Помилка видалення: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                string fileName = Path.GetFileName(filePath);

                try
                {
                    using (WebClient client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                        toolStripProgressBar1.Style = ProgressBarStyle.Marquee;
                        lblStatus.Text = $"Завантаження {fileName}...";

                        client.UploadProgressChanged += (s, ev) =>
                        {
                            toolStripProgressBar1.Value = ev.ProgressPercentage;
                        };

                        client.UploadFileCompleted += (s, ev) =>
                        {
                            if (ev.Error != null)
                            {
                                MessageBox.Show("Помилка завантаження: " + ev.Error.Message, "Помилка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show("Файл успішно завантажено", "Інформація",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ListDirectoryDetails(currentDirectory);
                            }
                            toolStripProgressBar1.Style = ProgressBarStyle.Blocks;
                            lblStatus.Text = "Готово";
                        };

                        client.UploadFileAsync(new Uri("ftp://" + txtHost.Text + currentDirectory + fileName),
                            WebRequestMethods.Ftp.UploadFile, filePath);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка завантаження: " + ex.Message, "Помилка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    toolStripProgressBar1.Style = ProgressBarStyle.Blocks;
                    lblStatus.Text = "Готово";
                }
            }
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 1 && saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = listView1.SelectedItems[0].Text;
                string savePath = saveFileDialog1.FileName;

                try
                {
                    using (WebClient client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                        toolStripProgressBar1.Style = ProgressBarStyle.Marquee;
                        lblStatus.Text = $"Завантаження {fileName}...";

                        client.DownloadProgressChanged += (s, ev) =>
                        {
                            toolStripProgressBar1.Value = ev.ProgressPercentage;
                        };

                        client.DownloadFileCompleted += (s, ev) =>
                        {
                            if (ev.Error != null)
                            {
                                MessageBox.Show("Помилка завантаження: " + ev.Error.Message, "Помилка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show("Файл успішно завантажено", "Інформація",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            toolStripProgressBar1.Style = ProgressBarStyle.Blocks;
                            lblStatus.Text = "Готово";
                        };

                        client.DownloadFileAsync(new Uri("ftp://" + txtHost.Text + currentDirectory + fileName), savePath);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка завантаження: " + ex.Message, "Помилка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    toolStripProgressBar1.Style = ProgressBarStyle.Blocks;
                    lblStatus.Text = "Готово";
                }
            }
        }

        private void btnUploadFolder_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                string folderPath = folderBrowserDialog1.SelectedPath;
                string folderName = new DirectoryInfo(folderPath).Name;

                try
                {
                    // Створення папки на сервері
                    FtpWebRequest dirRequest = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + currentDirectory + folderName + "/");
                    dirRequest.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                    dirRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
                    dirRequest.UsePassive = passiveMode;

                    using (FtpWebResponse dirResponse = (FtpWebResponse)dirRequest.GetResponse())
                    {
                        // Завантаження всіх файлів з папки
                        UploadDirectory(folderPath, currentDirectory + folderName + "/");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка завантаження папки: " + ex.Message, "Помилка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UploadDirectory(string localPath, string remotePath)
        {
            try
            {
                // Завантаження файлів
                foreach (string filePath in Directory.GetFiles(localPath))
                {
                    string fileName = Path.GetFileName(filePath);
                    using (WebClient client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                        lblStatus.Text = $"Завантаження {fileName}...";
                        Application.DoEvents();

                        client.UploadFile("ftp://" + txtHost.Text + remotePath + fileName,
                            WebRequestMethods.Ftp.UploadFile, filePath);
                    }
                }

                // Рекурсивне завантаження підпапок
                foreach (string subDir in Directory.GetDirectories(localPath))
                {
                    string dirName = new DirectoryInfo(subDir).Name;

                    // Створення підпапки на сервері
                    FtpWebRequest dirRequest = (FtpWebRequest)WebRequest.Create("ftp://" + txtHost.Text + remotePath + dirName + "/");
                    dirRequest.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                    dirRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
                    dirRequest.UsePassive = passiveMode;

                    using (FtpWebResponse dirResponse = (FtpWebResponse)dirRequest.GetResponse())
                    {
                        UploadDirectory(subDir, remotePath + dirName + "/");
                    }
                }

                MessageBox.Show("Папка успішно завантажена", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListDirectoryDetails(currentDirectory);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження папки: " + ex.Message, "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                lblStatus.Text = "Готово";
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            SettingsForm settingsForm = new SettingsForm(settings);
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                LoadSettings();
                txtHost.Text = settings.Host;
                txtUsername.Text = settings.Username;
                txtPassword.Text = settings.Password;
                passiveModeToolStripMenuItem.Checked = settings.PassiveMode;
            }
        }

        private void detailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            detailsToolStripMenuItem.Checked = true;
            iconsToolStripMenuItem.Checked = false;
            listToolStripMenuItem.Checked = false;
            tileToolStripMenuItem.Checked = false;
        }

        private void iconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.LargeIcon;
            detailsToolStripMenuItem.Checked = false;
            iconsToolStripMenuItem.Checked = true;
            listToolStripMenuItem.Checked = false;
            tileToolStripMenuItem.Checked = false;
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.List;
            detailsToolStripMenuItem.Checked = false;
            iconsToolStripMenuItem.Checked = false;
            listToolStripMenuItem.Checked = true;
            tileToolStripMenuItem.Checked = false;
        }

        private void tileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.Tile;
            detailsToolStripMenuItem.Checked = false;
            iconsToolStripMenuItem.Checked = false;
            listToolStripMenuItem.Checked = false;
            tileToolStripMenuItem.Checked = true;
        }

        private void passiveModeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            passiveMode = !passiveMode;
            passiveModeToolStripMenuItem.Checked = passiveMode;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("FTP Клієнт\nВерсія 1.0\n© 2023", "Про програму",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSettings();
        }
    }
}