﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;

namespace Lab29_
{
    public partial class Form1 : Form
    {
        bool alive = false; // чи буде працювати потік для приймання
        UdpClient client;
        int LOCALPORT = 8001; // порт для приймання повідомлень
        int REMOTEPORT = 8001; // порт для передавання повідомлень
        int TTL = 20;
        string HOST = "235.5.5.1"; // хост для групового розсилання
        IPAddress groupAddress; // адреса для групового розсилання

        string userName; // ім'я користувача в чаті
        Font chatFont = new Font("Microsoft Sans Serif", 10); // шрифт чату

        public Form1()
        {
            InitializeComponent();
            loginButton.Enabled = true; // кнопка входу
            logoutButton.Enabled = false; // кнопка виходу
            sendButton.Enabled = false; // кнопка відправки
            chatTextBox.ReadOnly = true; // поле для повідомлень

            groupAddress = IPAddress.Parse(HOST);
        }

        // обробник натискання кнопки loginButton
        private void loginButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(userNameTextBox.Text))
            {
                MessageBox.Show("Введіть ім'я користувача", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            userName = userNameTextBox.Text;
            userNameTextBox.ReadOnly = true;

            try
            {
                client = new UdpClient(LOCALPORT);
                // підєднання до групового розсилання
                client.JoinMulticastGroup(groupAddress, TTL);

                // задача на приймання повідомлень
                Task receiveTask = new Task(ReceiveMessages);
                alive = true;
                receiveTask.Start();

                // перше повідомлення про вхід нового користувача
                string message = userName + " увійшов у чат";
                byte[] data = Encoding.Unicode.GetBytes(message);
                client.Send(data, data.Length, HOST, REMOTEPORT);

                loginButton.Enabled = false;
                logoutButton.Enabled = true;
                sendButton.Enabled = true;

                statusLabel.Text = "Підключено до чату як " + userName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Помилка підключення", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // метод приймання повідомлення
        private void ReceiveMessages()
        {
            try
            {
                while (alive)
                {
                    IPEndPoint remoteIp = null;
                    byte[] data = client.Receive(ref remoteIp);
                    string message = Encoding.Unicode.GetString(data);

                    // додаємо отримане повідомлення в текстове поле
                    this.Invoke(new MethodInvoker(() =>
                    {
                        string time = DateTime.Now.ToShortTimeString();
                        chatTextBox.AppendText(time + " " + message + "\r\n");
                    }));
                }
            }
            catch (ObjectDisposedException)
            {
                if (!alive)
                    return;
                throw;
            }
            catch (Exception ex)
            {
                this.Invoke(new MethodInvoker(() =>
                {
                    MessageBox.Show(ex.Message, "Помилка отримання повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }));
            }
        }

        // обробник натискання кнопки sendButton
        private void sendButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(messageTextBox.Text))
            {
                MessageBox.Show("Введіть повідомлення", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string message = String.Format("{0}: {1}", userName, messageTextBox.Text);
                byte[] data = Encoding.Unicode.GetBytes(message);
                client.Send(data, data.Length, HOST, REMOTEPORT);
                messageTextBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Помилка відправки", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // обробник натискання кнопки logoutButton
        private void logoutButton_Click(object sender, EventArgs e)
        {
            ExitChat();
        }

        // вихід з чату
        private void ExitChat()
        {
            string message = userName + " вийшов з чату";
            byte[] data = Encoding.Unicode.GetBytes(message);
            client.Send(data, data.Length, HOST, REMOTEPORT);
            client.DropMulticastGroup(groupAddress);
            alive = false;
            client.Close();

            loginButton.Enabled = true;
            logoutButton.Enabled = false;
            sendButton.Enabled = false;
            userNameTextBox.ReadOnly = false;

            statusLabel.Text = "Не підключено до чату";
        }

        // обробник події закриття форми
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (alive)
                ExitChat();
        }

        // збереження логу чату у файл
        private void saveLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Текстові файли (*.txt)|*.txt|Усі файли (*.*)|*.*";
            saveFileDialog.Title = "Зберегти лог чату";
            saveFileDialog.FileName = "Чат_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.WriteAllText(saveFileDialog.FileName, chatTextBox.Text);
                    MessageBox.Show("Лог чату збережено успішно", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка збереження файлу: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // вихід з програми
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // налаштування мережевих параметрів
        private void networkSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new NetworkSettingsForm(HOST, LOCALPORT, REMOTEPORT, TTL))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    if (alive)
                    {
                        MessageBox.Show("Зміни вступлять в силу після перепідключення", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    HOST = form.MulticastAddress;
                    LOCALPORT = form.LocalPort;
                    REMOTEPORT = form.RemotePort;
                    TTL = form.TTL;
                    groupAddress = IPAddress.Parse(HOST);
                }
            }
        }

        // налаштування шрифту
        private void fontSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.Font = chatFont;

            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                chatFont = fontDialog.Font;
                chatTextBox.Font = chatFont;
                messageTextBox.Font = chatFont;
            }
        }
    }
}
