﻿using System;
using System.Windows.Forms;

namespace Lab29_
{
    public partial class NetworkSettingsForm : Form
    {
        public string MulticastAddress { get; private set; }
        public int LocalPort { get; private set; }
        public int RemotePort { get; private set; }
        public int TTL { get; private set; }

        public NetworkSettingsForm(string address, int localPort, int remotePort, int ttl)
        {
            InitializeComponent();

            addressTextBox.Text = address;
            localPortTextBox.Text = localPort.ToString();
            remotePortTextBox.Text = remotePort.ToString();
            ttlTextBox.Text = ttl.ToString();
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            try
            {
                MulticastAddress = addressTextBox.Text;
                LocalPort = int.Parse(localPortTextBox.Text);
                RemotePort = int.Parse(remotePortTextBox.Text);
                TTL = int.Parse(ttlTextBox.Text);

                if (LocalPort < 1 || LocalPort > 65535 || RemotePort < 1 || RemotePort > 65535)
                {
                    MessageBox.Show("Порт повинен бути в діапазоні 1-65535", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (TTL < 1 || TTL > 255)
                {
                    MessageBox.Show("TTL повинен бути в діапазоні 1-255", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Введіть коректні числові значення", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #region Windows Form Designer generated code

        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox localPortTextBox;
        private System.Windows.Forms.TextBox remotePortTextBox;
        private System.Windows.Forms.TextBox ttlTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;

        private void InitializeComponent()
        {
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.localPortTextBox = new System.Windows.Forms.TextBox();
            this.remotePortTextBox = new System.Windows.Forms.TextBox();
            this.ttlTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // addressTextBox
            this.addressTextBox.Location = new System.Drawing.Point(120, 20);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(150, 20);
            this.addressTextBox.TabIndex = 0;

            // localPortTextBox
            this.localPortTextBox.Location = new System.Drawing.Point(120, 50);
            this.localPortTextBox.Name = "localPortTextBox";
            this.localPortTextBox.Size = new System.Drawing.Size(150, 20);
            this.localPortTextBox.TabIndex = 1;

            // remotePortTextBox
            this.remotePortTextBox.Location = new System.Drawing.Point(120, 80);
            this.remotePortTextBox.Name = "remotePortTextBox";
            this.remotePortTextBox.Size = new System.Drawing.Size(150, 20);
            this.remotePortTextBox.TabIndex = 2;

            // ttlTextBox
            this.ttlTextBox.Location = new System.Drawing.Point(120, 110);
            this.ttlTextBox.Name = "ttlTextBox";
            this.ttlTextBox.Size = new System.Drawing.Size(150, 20);
            this.ttlTextBox.TabIndex = 3;

            // label1
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Групова адреса:";

            // label2
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Локальний порт:";

            // label3
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Віддалений порт:";

            // label4
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "TTL:";

            // okButton
            this.okButton.Location = new System.Drawing.Point(70, 150);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 8;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);

            // cancelButton
            this.cancelButton.Location = new System.Drawing.Point(160, 150);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 9;
            this.cancelButton.Text = "Скасувати";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);

            // NetworkSettingsForm
            this.AcceptButton = this.okButton;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(300, 190);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ttlTextBox);
            this.Controls.Add(this.remotePortTextBox);
            this.Controls.Add(this.localPortTextBox);
            this.Controls.Add(this.addressTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NetworkSettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Мережеві налаштування";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}

