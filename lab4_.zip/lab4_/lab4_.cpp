﻿#include <iostream>
#include "BitString.h"
#include <string>
using namespace std;
int main()
{
	//AND
	BitString A(25, 11);
	BitString B(19, 26);
	BitString C;
	A.Display();
	B.Display();
	C = A & B;
	C.ToString();

	//OR
	BitString E;
	BitString F;
	BitString D;
	E.Read();
	E.Display();
	F.Display();
	D = E | F;
	D.ToString();

	//XOR
	BitString G;
	BitString H(68);
	BitString I;
	G.Display();
	H.Display();
	I = G ^ H;
	I.ToString();

	//NOT
	BitString K(-201, -69);
	BitString L;
	cout << "First binary string = -201, second binary string = -69"<< endl;
	L = ~K;
	L.ToString();

	//Змінні для здвигу на задану кількість бітів
	unsigned long shiftRightBit, shiftLeftBit;

	BitString a, b, c, d;

	//Зчитування рядків та здвиг обох вліво
	a.Display();
	cout << "Enter shift left bit ";
	cin >> shiftLeftBit;
	b = a.shiftLeft(shiftLeftBit);
	b.ToString();
	cout << endl;

	//Задання рядків та здвиг обох вправо
	c = c.Init(26, 14);
	c.Display();
	cout << "Enter shift right bit ";
	cin >> shiftRightBit;
	d = c.shiftRight(shiftRightBit);
	d.ToString();
	cout << endl;

}