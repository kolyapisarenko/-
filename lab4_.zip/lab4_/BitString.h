#pragma once
#include <string>
using namespace std;
class BitString
{
	unsigned long first;
	unsigned long second;
public:
	void Read();
	void Display();
	BitString Init(unsigned long f, unsigned long s);
	void ToString();
	BitString shiftLeft(unsigned long bit);
	BitString shiftRight(unsigned long bit);
	BitString operator &(BitString m1);
	BitString operator |(BitString m1);
	BitString operator ^(BitString m1);
	BitString operator ~();
	BitString();
	BitString(unsigned long f);
	BitString(unsigned long f, unsigned long s);
};