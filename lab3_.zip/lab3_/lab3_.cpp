﻿#include <iostream>
#include "BitString.h"
#include <string>

using namespace std;

int main()
{
    //Константа для методів AND, OR, XOR
    const unsigned long number = 25;

    //Змінні для здвигу на задану кількість бітів
    unsigned long shiftRightBit, shiftLeftBit;

    BitString a, b, c, d, e(25), f, g, h, i(19, 125), l, k, m;

    //Зчитування рядків та здвиг обох вліво
    a.Display();
    cout << "Enter shift left bit ";
    cin >> shiftLeftBit;
    b = a.shiftLeft(shiftLeftBit);
    b.ToString();
    cout << endl;

    //Задання рядків та здвиг обох вправо
    c = c.Init(26, 14);
    c.Display();
    cout << "Enter shift right bit ";
    cin >> shiftRightBit;
    d = c.shiftRight(shiftRightBit);
    d.ToString();
    cout << endl;

    //Зчитування рядків з конструктора та операція and
    e.Display();
    f = e.AND(number);
    f.ToString();
    cout << endl;

    //Зчитування рядків та операція or
    g.Read();
    g.Display();
    h = g.OR(number);
    h.ToString();
    cout << endl;

    //Зчитування рядків з конструктора та операція xor
    i.Display();
    l = i.XOR(number);
    l.ToString();
    cout << endl;
    
    //Зчитування рядків та операція not
    k = k.Init(-82, -14);
    cout << "First binary string = -82, second binary string = -14" << endl;
    m = k.NOT();
    m.ToString();
    cout << endl;
}