﻿using System;
using System.Security.Cryptography;

namespace Lab24_
{
    public class BlowfishManaged : SymmetricAlgorithm
    {
        public BlowfishManaged()
        {
            // Встановлюємо стандартні значення
            this.KeySizeValue = 448; // 448 біт (56 байт)
            this.BlockSizeValue = 64; // 64 біт (8 байт)
            this.Mode = CipherMode.ECB;
            this.Padding = PaddingMode.PKCS7;

            // Ініціалізуємо ключ та IV
            this.GenerateKey();
            this.GenerateIV();
        }

        public override ICryptoTransform CreateDecryptor(byte[] rgbKey, byte[] rgbIV)
        {
            return CreateEncryptor(rgbKey, rgbIV);
        }

        public override ICryptoTransform CreateEncryptor(byte[] rgbKey, byte[] rgbIV)
        {
            // Використовуємо надані ключ та IV або генеруємо нові
            byte[] key = rgbKey ?? this.Key;
            byte[] iv = rgbIV ?? this.IV;

            // Перевірка на нульові значення
            if (key == null || key.Length == 0)
            {
                this.GenerateKey();
                key = this.Key;
            }

            if (iv == null || iv.Length == 0)
            {
                this.GenerateIV();
                iv = this.IV;
            }

            return new BlowfishTransform(key, iv);
        }

        public override void GenerateIV()
        {
            // IV розміром 8 байт (64 біта)
            this.IVValue = new byte[8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(this.IVValue);
            }
        }

        public override void GenerateKey()
        {
            // Ключ розміром 56 байт (448 біт)
            this.KeyValue = new byte[56];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(this.KeyValue);
            }
        }
    }

    internal class BlowfishTransform : ICryptoTransform
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public BlowfishTransform(byte[] key, byte[] iv)
        {
            _key = key ?? throw new ArgumentNullException(nameof(key));
            _iv = iv ?? throw new ArgumentNullException(nameof(iv));
        }

        public bool CanReuseTransform => true;
        public bool CanTransformMultipleBlocks => true;
        public int InputBlockSize => 8; // 64-бітні блоки
        public int OutputBlockSize => 8;

        public int TransformBlock(byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
        {
            // Проста XOR-реалізація для демонстрації
            for (int i = 0; i < inputCount; i++)
            {
                outputBuffer[outputOffset + i] = (byte)(inputBuffer[inputOffset + i] ^ _key[i % _key.Length]);
            }
            return inputCount;
        }

        public byte[] TransformFinalBlock(byte[] inputBuffer, int inputOffset, int inputCount)
        {
            byte[] output = new byte[inputCount];
            TransformBlock(inputBuffer, inputOffset, inputCount, output, 0);
            return output;
        }

        public void Dispose()
        {
            // Очищаємо ресурси
            Array.Clear(_key, 0, _key.Length);
            Array.Clear(_iv, 0, _iv.Length);
        }
    }
}