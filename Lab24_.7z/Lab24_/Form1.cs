﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Security.Cryptography;
using System.Text;
using System.Linq;

namespace Lab24_
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
            InitializeThreads();
        }

        private Thread thread1, thread2, thread3;
        private volatile bool running = true;
        private readonly object lockObj = new object();

        private void InitializeThreads()
        {
            thread1 = new Thread(BlowfishEncrypt) { IsBackground = true };
            thread2 = new Thread(MD5Hash) { IsBackground = true };
            thread3 = new Thread(WAKEEncrypt) { IsBackground = true };
        }

        private void BlowfishEncrypt()
        {
            try
            {
                using (var blowfish = new BlowfishManaged())
                {
                    while (running)
                    {
                        byte[] data = new byte[8]; // 64-bit block
                        new Random().NextBytes(data);

                        byte[] encrypted;
                        using (var encryptor = blowfish.CreateEncryptor())
                        {
                            encrypted = encryptor.TransformFinalBlock(data, 0, data.Length);
                        }

                        UpdateTextBox(textBox1, $"Original: {BitConverter.ToString(data)}\r\nEncrypted: {BitConverter.ToString(encrypted)}\r\n\r\n");
                        Thread.Sleep(500);
                    }
                }
            }
            catch (ThreadAbortException) { }
            catch (Exception ex)
            {
                ShowError($"Blowfish error: {ex.Message}");
            }
        }

        // Метод 2: MD5 хешування
        private void MD5Hash()
        {
            try
            {
                using (var md5 = MD5.Create())
                {
                    while (running)
                    {
                        // Генеруємо випадкові дані для хешування
                        byte[] data = new byte[64];
                        new Random().NextBytes(data);

                        // Обчислюємо хеш
                        byte[] hash = md5.ComputeHash(data);

                        // Виводимо результати
                        textBox2.Invoke((MethodInvoker)delegate
                        {
                            textBox2.AppendText($"Data: {BitConverter.ToString(data)}\r\n");
                            textBox2.AppendText($"Hash: {BitConverter.ToString(hash)}\r\n\r\n");

                            // Обмеження кількості рядків
                            if (textBox2.Lines.Length > 50)
                            {
                                textBox2.Lines = textBox2.Lines.Skip(textBox2.Lines.Length - 20).ToArray();
                            }
                        });

                        Thread.Sleep(500);
                    }
                }
            }
            catch (ThreadAbortException) { }
            catch (Exception ex)
            {
                MessageBox.Show($"MD5 error: {ex.Message}");
            }
        }

        // Метод 3: WAKE шифрування
        private void WAKEEncrypt()
        {
            try
            {
                // WAKE реалізація (спрощена)
                while (running)
                {
                    // Генеруємо випадкові дані
                    byte[] data = new byte[64];
                    new Random().NextBytes(data);

                    // Просте "шифрування" XOR
                    byte[] key = new byte[64];
                    new Random().NextBytes(key);
                    byte[] encrypted = new byte[64];
                    for (int i = 0; i < 64; i++)
                    {
                        encrypted[i] = (byte)(data[i] ^ key[i]);
                    }

                    // Виводимо результати
                    textBox3.Invoke((MethodInvoker)delegate
                    {
                        textBox3.AppendText($"Original: {BitConverter.ToString(data)}\r\n");
                        textBox3.AppendText($"Encrypted: {BitConverter.ToString(encrypted)}\r\n\r\n");

                        // Обмеження кількості рядків
                        if (textBox3.Lines.Length > 50)
                        {
                            textBox3.Lines = textBox3.Lines.Skip(textBox3.Lines.Length - 20).ToArray();
                        }
                    });

                    Thread.Sleep(500);
                }
            }
            catch (ThreadAbortException) { }
            catch (Exception ex)
            {
                MessageBox.Show($"WAKE error: {ex.Message}");
            }
        }

        private void UpdateTextBox(TextBox box, string text)
        {
            if (box.InvokeRequired)
            {
                box.Invoke((MethodInvoker)delegate { UpdateTextBox(box, text); });
                return;
            }

            box.AppendText(text);

            // Обмеження кількості рядків
            if (box.Lines.Length > 50)
            {
                box.Text = string.Join(Environment.NewLine, box.Lines.Skip(box.Lines.Length - 20));
            }
        }

        private void ShowError(string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { ShowError(message); });
                return;
            }
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Оновлені обробники кнопок
        private void btnStart1_Click(object sender, EventArgs e)
        {
            try
            {
                if (thread1 == null || thread1.ThreadState == ThreadState.Stopped)
                {
                    thread1 = new Thread(BlowfishEncrypt) { IsBackground = true };
                }

                if ((thread1.ThreadState & ThreadState.Unstarted) != 0)
                {
                    running = true;
                    thread1.Start();
                }
                else if (thread1.ThreadState == ThreadState.Suspended)
                {
                    thread1.Resume();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Failed to start BLOWFISH: {ex.Message}");
            }
        }

        private void btnStop1_Click(object sender, EventArgs e)
        {
            try
            {
                running = false;
                thread1?.Join(500);
                thread1 = null;
            }
            catch (Exception ex)
            {
                ShowError($"Failed to stop BLOWFISH: {ex.Message}");
            }
        }

        private void btnStart2_Click(object sender, EventArgs e)
        {
            try
            {
                if (thread2 == null || thread2.ThreadState == ThreadState.Stopped)
                {
                    thread2 = new Thread(BlowfishEncrypt) { IsBackground = true };
                }

                if ((thread2.ThreadState & ThreadState.Unstarted) != 0)
                {
                    running = true;
                    thread2.Start();
                }
                else if (thread2.ThreadState == ThreadState.Suspended)
                {
                    thread2.Resume();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Failed to start BLOWFISH: {ex.Message}");
            }
        }

        private void btnStop2_Click(object sender, EventArgs e)
        {
            try
            {
                running = false;
                thread2?.Join(500);
                thread2 = null;
            }
            catch (Exception ex)
            {
                ShowError($"Failed to stop MD5: {ex.Message}");
            }
        }
        private void btnStart3_Click(object sender, EventArgs e)
        {
            try
            {
                if (thread3 == null || thread3.ThreadState == ThreadState.Stopped)
                {
                    thread3 = new Thread(BlowfishEncrypt) { IsBackground = true };
                }

                if ((thread3.ThreadState & ThreadState.Unstarted) != 0)
                {
                    running = true;
                    thread3.Start();
                }
                else if (thread3.ThreadState == ThreadState.Suspended)
                {
                    thread3.Resume();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Failed to start BLOWFISH: {ex.Message}");
            }
        }


        private void btnStop3_Click(object sender, EventArgs e)
        {
            try
            {
                running = false;
                thread3?.Join(500);
                thread3 = null;
            }
            catch (Exception ex)
            {
                ShowError($"Failed to stop Wake: {ex.Message}");
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            running = false;

            try { thread1?.Join(300); } catch { }
            try { thread2?.Join(300); } catch { }
            try { thread3?.Join(300); } catch { }
        }
        private void btnStartAll_Click(object sender, EventArgs e)
        {
            try
            {
                // Запускаємо всі потоки
                btnStart1_Click(sender, e);
                btnStart2_Click(sender, e);
                btnStart3_Click(sender, e);
            }
            catch (Exception ex)
            {
                ShowError($"Failed to start all threads: {ex.Message}");
            }
        }

        private void btnStopAll_Click(object sender, EventArgs e)
        {
            running = false;

            try { thread1?.Join(300); } catch { }
            try { thread2?.Join(300); } catch { }
            try { thread3?.Join(300); } catch { }

            thread1 = thread2 = thread3 = null;
        }
    }
}