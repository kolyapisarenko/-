﻿// staticLib.cpp : Defines the functions for the static library.
//

#include "framework.h"

// TODO: This is an example of a library function
void fnstaticLib()
{
}
