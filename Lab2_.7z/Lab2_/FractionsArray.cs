﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_
{
    internal class FractionsArray
    {
        private List<Fractions> fractionsList;
        public FractionsArray()
        {
            fractionsList = new List<Fractions>();
        }
        public void Add(Fractions fraction)
        {
            fractionsList.Add(fraction);
        }
        public void SortFractions()
        {
            fractionsList.Sort((f1, f2) => (f1.Numerator * f2.Denominator).CompareTo(f2.Numerator * f1.Denominator));
        }
        public int GetLength()
        {
            return fractionsList.Count;
        }
        public IEnumerator<Fractions> GetEnumerator()
        {
            return fractionsList.GetEnumerator();
        }
    }
}
