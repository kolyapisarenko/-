﻿namespace Lab2_
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listBoxFractions = new System.Windows.Forms.ListBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblException = new System.Windows.Forms.Label();
            this.btnShow = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtDenominator = new System.Windows.Forms.TextBox();
            this.txtNumerator = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblExceptionOutput = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            this.txtPowNumber = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.lblPowResult = new System.Windows.Forms.Label();
            this.lblDivResult = new System.Windows.Forms.Label();
            this.lblMulResult = new System.Windows.Forms.Label();
            this.lblSepResult = new System.Windows.Forms.Label();
            this.lblSumResult = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblOperationSecondFraction = new System.Windows.Forms.Label();
            this.lblOperationFirstFraction = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnGetComparison = new System.Windows.Forms.Button();
            this.lblIsLessEqual = new System.Windows.Forms.Label();
            this.lblIsGreaterEqual = new System.Windows.Forms.Label();
            this.lblIsLess = new System.Windows.Forms.Label();
            this.lblIsGreater = new System.Windows.Forms.Label();
            this.lblIsNoEqual = new System.Windows.Forms.Label();
            this.lblIsEqual = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblSecondFraction = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblFirstFraction = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.listBoxSortedShow = new System.Windows.Forms.ListBox();
            this.btnShowSorted = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(8, 8);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1372, 716);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1364, 684);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Умова";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Lab2_.Properties.Resources._1;
            this.pictureBox1.Location = new System.Drawing.Point(28, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1330, 402);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listBoxFractions);
            this.tabPage2.Controls.Add(this.btnClear);
            this.tabPage2.Controls.Add(this.lblException);
            this.tabPage2.Controls.Add(this.btnShow);
            this.tabPage2.Controls.Add(this.btnSave);
            this.tabPage2.Controls.Add(this.txtDenominator);
            this.tabPage2.Controls.Add(this.txtNumerator);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1364, 684);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Введення дробів";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listBoxFractions
            // 
            this.listBoxFractions.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBoxFractions.FormattingEnabled = true;
            this.listBoxFractions.ItemHeight = 26;
            this.listBoxFractions.Location = new System.Drawing.Point(61, 354);
            this.listBoxFractions.Name = "listBoxFractions";
            this.listBoxFractions.Size = new System.Drawing.Size(470, 238);
            this.listBoxFractions.TabIndex = 8;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClear.Location = new System.Drawing.Point(519, 214);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(155, 71);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Очистити поля";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblException
            // 
            this.lblException.AutoSize = true;
            this.lblException.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblException.ForeColor = System.Drawing.Color.Red;
            this.lblException.Location = new System.Drawing.Point(61, 157);
            this.lblException.Name = "lblException";
            this.lblException.Size = new System.Drawing.Size(0, 26);
            this.lblException.TabIndex = 6;
            // 
            // btnShow
            // 
            this.btnShow.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnShow.Location = new System.Drawing.Point(281, 214);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(164, 71);
            this.btnShow.TabIndex = 5;
            this.btnShow.Text = "Відобразити дроби";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSave.Location = new System.Drawing.Point(66, 214);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(140, 71);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Зберегти дріб";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtDenominator
            // 
            this.txtDenominator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtDenominator.Location = new System.Drawing.Point(375, 88);
            this.txtDenominator.Name = "txtDenominator";
            this.txtDenominator.Size = new System.Drawing.Size(156, 34);
            this.txtDenominator.TabIndex = 3;
            this.txtDenominator.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDenominator_KeyPress);
            // 
            // txtNumerator
            // 
            this.txtNumerator.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtNumerator.Location = new System.Drawing.Point(375, 28);
            this.txtNumerator.Name = "txtNumerator";
            this.txtNumerator.Size = new System.Drawing.Size(156, 34);
            this.txtNumerator.TabIndex = 2;
            this.txtNumerator.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumerator_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(59, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(258, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Введіть знаменник дробу";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(61, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введіть чисельник дробу";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblExceptionOutput);
            this.tabPage3.Controls.Add(this.btnResult);
            this.tabPage3.Controls.Add(this.txtPowNumber);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.lblPowResult);
            this.tabPage3.Controls.Add(this.lblDivResult);
            this.tabPage3.Controls.Add(this.lblMulResult);
            this.tabPage3.Controls.Add(this.lblSepResult);
            this.tabPage3.Controls.Add(this.lblSumResult);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.lblOperationSecondFraction);
            this.tabPage3.Controls.Add(this.lblOperationFirstFraction);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1364, 684);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Операції з дробами";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblExceptionOutput
            // 
            this.lblExceptionOutput.AutoSize = true;
            this.lblExceptionOutput.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblExceptionOutput.ForeColor = System.Drawing.Color.Red;
            this.lblExceptionOutput.Location = new System.Drawing.Point(68, 166);
            this.lblExceptionOutput.Name = "lblExceptionOutput";
            this.lblExceptionOutput.Size = new System.Drawing.Size(0, 26);
            this.lblExceptionOutput.TabIndex = 17;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResult.Location = new System.Drawing.Point(358, 497);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(186, 43);
            this.btnResult.TabIndex = 16;
            this.btnResult.Text = "Обчислити";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // txtPowNumber
            // 
            this.txtPowNumber.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtPowNumber.Location = new System.Drawing.Point(809, 35);
            this.txtPowNumber.Name = "txtPowNumber";
            this.txtPowNumber.Size = new System.Drawing.Size(100, 34);
            this.txtPowNumber.TabIndex = 15;
            this.txtPowNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDenominator_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(471, 43);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(288, 26);
            this.label25.TabIndex = 14;
            this.label25.Text = "Введіть натуральний степінь";
            // 
            // lblPowResult
            // 
            this.lblPowResult.AutoSize = true;
            this.lblPowResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPowResult.Location = new System.Drawing.Point(573, 439);
            this.lblPowResult.Name = "lblPowResult";
            this.lblPowResult.Size = new System.Drawing.Size(0, 26);
            this.lblPowResult.TabIndex = 13;
            // 
            // lblDivResult
            // 
            this.lblDivResult.AutoSize = true;
            this.lblDivResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDivResult.Location = new System.Drawing.Point(573, 386);
            this.lblDivResult.Name = "lblDivResult";
            this.lblDivResult.Size = new System.Drawing.Size(0, 26);
            this.lblDivResult.TabIndex = 12;
            // 
            // lblMulResult
            // 
            this.lblMulResult.AutoSize = true;
            this.lblMulResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMulResult.Location = new System.Drawing.Point(573, 329);
            this.lblMulResult.Name = "lblMulResult";
            this.lblMulResult.Size = new System.Drawing.Size(0, 26);
            this.lblMulResult.TabIndex = 11;
            // 
            // lblSepResult
            // 
            this.lblSepResult.AutoSize = true;
            this.lblSepResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSepResult.Location = new System.Drawing.Point(573, 276);
            this.lblSepResult.Name = "lblSepResult";
            this.lblSepResult.Size = new System.Drawing.Size(0, 26);
            this.lblSepResult.TabIndex = 10;
            // 
            // lblSumResult
            // 
            this.lblSumResult.AutoSize = true;
            this.lblSumResult.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSumResult.Location = new System.Drawing.Point(573, 222);
            this.lblSumResult.Name = "lblSumResult";
            this.lblSumResult.Size = new System.Drawing.Size(0, 26);
            this.lblSumResult.TabIndex = 9;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(66, 439);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(455, 26);
            this.label19.TabIndex = 8;
            this.label19.Text = "Результат піднесення в степінь другого дробу";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(67, 386);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(183, 26);
            this.label18.TabIndex = 7;
            this.label18.Text = "Результат ділення";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(67, 329);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(208, 26);
            this.label17.TabIndex = 6;
            this.label17.Text = "Результат множення";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(66, 276);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(216, 26);
            this.label16.TabIndex = 5;
            this.label16.Text = "Результат віднімання";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(67, 222);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(210, 26);
            this.label15.TabIndex = 4;
            this.label15.Text = "Результат додавання";
            // 
            // lblOperationSecondFraction
            // 
            this.lblOperationSecondFraction.AutoSize = true;
            this.lblOperationSecondFraction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOperationSecondFraction.Location = new System.Drawing.Point(305, 95);
            this.lblOperationSecondFraction.Name = "lblOperationSecondFraction";
            this.lblOperationSecondFraction.Size = new System.Drawing.Size(0, 26);
            this.lblOperationSecondFraction.TabIndex = 3;
            // 
            // lblOperationFirstFraction
            // 
            this.lblOperationFirstFraction.AutoSize = true;
            this.lblOperationFirstFraction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOperationFirstFraction.Location = new System.Drawing.Point(305, 42);
            this.lblOperationFirstFraction.Name = "lblOperationFirstFraction";
            this.lblOperationFirstFraction.Size = new System.Drawing.Size(0, 26);
            this.lblOperationFirstFraction.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(67, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Другий дріб";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(66, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "Перший дріб";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnGetComparison);
            this.tabPage4.Controls.Add(this.lblIsLessEqual);
            this.tabPage4.Controls.Add(this.lblIsGreaterEqual);
            this.tabPage4.Controls.Add(this.lblIsLess);
            this.tabPage4.Controls.Add(this.lblIsGreater);
            this.tabPage4.Controls.Add(this.lblIsNoEqual);
            this.tabPage4.Controls.Add(this.lblIsEqual);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.lblSecondFraction);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.lblFirstFraction);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1364, 684);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Порівняння дробів";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnGetComparison
            // 
            this.btnGetComparison.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnGetComparison.Location = new System.Drawing.Point(83, 497);
            this.btnGetComparison.Name = "btnGetComparison";
            this.btnGetComparison.Size = new System.Drawing.Size(162, 77);
            this.btnGetComparison.TabIndex = 16;
            this.btnGetComparison.Text = "Отримати значення";
            this.btnGetComparison.UseVisualStyleBackColor = true;
            this.btnGetComparison.Click += new System.EventHandler(this.btnGetComparison_Click);
            // 
            // lblIsLessEqual
            // 
            this.lblIsLessEqual.AutoSize = true;
            this.lblIsLessEqual.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsLessEqual.Location = new System.Drawing.Point(484, 429);
            this.lblIsLessEqual.Name = "lblIsLessEqual";
            this.lblIsLessEqual.Size = new System.Drawing.Size(0, 26);
            this.lblIsLessEqual.TabIndex = 15;
            // 
            // lblIsGreaterEqual
            // 
            this.lblIsGreaterEqual.AutoSize = true;
            this.lblIsGreaterEqual.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsGreaterEqual.Location = new System.Drawing.Point(484, 380);
            this.lblIsGreaterEqual.Name = "lblIsGreaterEqual";
            this.lblIsGreaterEqual.Size = new System.Drawing.Size(0, 26);
            this.lblIsGreaterEqual.TabIndex = 14;
            // 
            // lblIsLess
            // 
            this.lblIsLess.AutoSize = true;
            this.lblIsLess.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsLess.Location = new System.Drawing.Point(484, 331);
            this.lblIsLess.Name = "lblIsLess";
            this.lblIsLess.Size = new System.Drawing.Size(0, 26);
            this.lblIsLess.TabIndex = 13;
            // 
            // lblIsGreater
            // 
            this.lblIsGreater.AutoSize = true;
            this.lblIsGreater.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsGreater.Location = new System.Drawing.Point(484, 276);
            this.lblIsGreater.Name = "lblIsGreater";
            this.lblIsGreater.Size = new System.Drawing.Size(0, 26);
            this.lblIsGreater.TabIndex = 12;
            // 
            // lblIsNoEqual
            // 
            this.lblIsNoEqual.AutoSize = true;
            this.lblIsNoEqual.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsNoEqual.Location = new System.Drawing.Point(484, 221);
            this.lblIsNoEqual.Name = "lblIsNoEqual";
            this.lblIsNoEqual.Size = new System.Drawing.Size(0, 26);
            this.lblIsNoEqual.TabIndex = 11;
            // 
            // lblIsEqual
            // 
            this.lblIsEqual.AutoSize = true;
            this.lblIsEqual.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblIsEqual.Location = new System.Drawing.Point(484, 163);
            this.lblIsEqual.Name = "lblIsEqual";
            this.lblIsEqual.Size = new System.Drawing.Size(0, 26);
            this.lblIsEqual.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(63, 429);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(360, 26);
            this.label12.TabIndex = 9;
            this.label12.Text = "Перший менше або рівний другому";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(62, 380);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(362, 26);
            this.label11.TabIndex = 8;
            this.label11.Text = "Перший більше або рівний другому";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(61, 331);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(243, 26);
            this.label10.TabIndex = 7;
            this.label10.Text = "Перший менше другого";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(61, 276);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(245, 26);
            this.label9.TabIndex = 6;
            this.label9.Text = "Перший більше другого";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(61, 221);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(157, 26);
            this.label8.TabIndex = 5;
            this.label8.Text = "Дроби не рівні";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(61, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 26);
            this.label7.TabIndex = 4;
            this.label7.Text = "Дроби рівні";
            // 
            // lblSecondFraction
            // 
            this.lblSecondFraction.AutoSize = true;
            this.lblSecondFraction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSecondFraction.Location = new System.Drawing.Point(239, 100);
            this.lblSecondFraction.Name = "lblSecondFraction";
            this.lblSecondFraction.Size = new System.Drawing.Size(0, 26);
            this.lblSecondFraction.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(61, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 26);
            this.label5.TabIndex = 2;
            this.label5.Text = "Другий дріб";
            // 
            // lblFirstFraction
            // 
            this.lblFirstFraction.AutoSize = true;
            this.lblFirstFraction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFirstFraction.Location = new System.Drawing.Point(239, 53);
            this.lblFirstFraction.Name = "lblFirstFraction";
            this.lblFirstFraction.Size = new System.Drawing.Size(0, 26);
            this.lblFirstFraction.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(61, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Перший дріб";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.listBoxSortedShow);
            this.tabPage5.Controls.Add(this.btnShowSorted);
            this.tabPage5.Location = new System.Drawing.Point(4, 28);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1364, 684);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Сортування масиву дробів";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // listBoxSortedShow
            // 
            this.listBoxSortedShow.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBoxSortedShow.FormattingEnabled = true;
            this.listBoxSortedShow.ItemHeight = 26;
            this.listBoxSortedShow.Location = new System.Drawing.Point(72, 161);
            this.listBoxSortedShow.Name = "listBoxSortedShow";
            this.listBoxSortedShow.Size = new System.Drawing.Size(460, 290);
            this.listBoxSortedShow.TabIndex = 2;
            // 
            // btnShowSorted
            // 
            this.btnShowSorted.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnShowSorted.Location = new System.Drawing.Point(72, 59);
            this.btnShowSorted.Name = "btnShowSorted";
            this.btnShowSorted.Size = new System.Drawing.Size(460, 62);
            this.btnShowSorted.TabIndex = 1;
            this.btnShowSorted.Text = "Відсортувати й відобразити масив";
            this.btnShowSorted.UseVisualStyleBackColor = true;
            this.btnShowSorted.Click += new System.EventHandler(this.btnShowSorted_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1392, 736);
            this.Controls.Add(this.tabControl1);
            this.Name = "mainForm";
            this.Text = "Lab2_";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox listBoxFractions;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblException;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtDenominator;
        private System.Windows.Forms.TextBox txtNumerator;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ListBox listBoxSortedShow;
        private System.Windows.Forms.Button btnShowSorted;
        private System.Windows.Forms.Button btnGetComparison;
        private System.Windows.Forms.Label lblIsLessEqual;
        private System.Windows.Forms.Label lblIsGreaterEqual;
        private System.Windows.Forms.Label lblIsLess;
        private System.Windows.Forms.Label lblIsGreater;
        private System.Windows.Forms.Label lblIsNoEqual;
        private System.Windows.Forms.Label lblIsEqual;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblSecondFraction;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblFirstFraction;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblOperationSecondFraction;
        private System.Windows.Forms.Label lblOperationFirstFraction;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.TextBox txtPowNumber;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblPowResult;
        private System.Windows.Forms.Label lblDivResult;
        private System.Windows.Forms.Label lblMulResult;
        private System.Windows.Forms.Label lblSepResult;
        private System.Windows.Forms.Label lblSumResult;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblExceptionOutput;
    }
}

