﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_
{
    public partial class mainForm : Form
    {
        FractionsArray a = new FractionsArray();
        Fractions f1 = new Fractions();
        Fractions f2;
        public mainForm()
        {
            InitializeComponent();
        }

        //Зберігання дробу в масив
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                lblException.Text = "";
                int n = Convert.ToInt32(txtNumerator.Text);
                int d = Convert.ToInt32(txtDenominator.Text);
                f2 = new Fractions(n, d);
                f2.Simplify();
                a.Add(f2);
            }
            catch (ArgumentException ex)
            {
                lblException.Text = ex.Message;
            }
            catch
            {
                if (txtNumerator.Text.Length == 0)
                {
                    txtNumerator.Focus();
                }
                else
                {
                    txtDenominator.Focus();
                }
            }
        }

        //Очищення полів для вводу
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNumerator.Clear();
            txtDenominator.Clear();
        }

        //Вібодраження масиву на вкладці введення
        private void btnShow_Click(object sender, EventArgs e)
        {
            if(a.GetLength() == 0)
            {
                listBoxFractions.Items.Clear();
                listBoxFractions.Items.Add("Ви не ввели жодного дробу.");
                txtNumerator.Focus();
            }
            else
            {
                listBoxFractions.Items.Clear();
                foreach(Fractions fractions in a)
                {
                    listBoxFractions.Items.Add(fractions.ToString());
                }
            }
        }

        //Обмеження текстових полів чисельника
        private void txtNumerator_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (e.KeyChar == '-' && textBox.SelectionStart == 0 && !textBox.Text.Contains("-"))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnSave.Focus();
                }
                return;
            }
            e.Handled = true;
        }

        //Обмеження вводу текстових полів знаменника
        private void txtDenominator_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnSave.Focus();
                    btnResult.Focus();
                }
                return;
            }
            e.Handled = true;
        }

        //Відображення відсортованого масиву дробів
        private void btnShowSorted_Click(object sender, EventArgs e)
        {
            a.SortFractions();
            if (a.GetLength() == 0)
            {
                listBoxSortedShow.Items.Clear();
                listBoxSortedShow.Items.Add("Ви не ввели жодного дробу.");
                txtNumerator.Focus();
            }
            else
            {
                listBoxSortedShow.Items.Clear();
                foreach (Fractions fractions in a)
                {
                    listBoxSortedShow.Items.Add(fractions.ToString());
                }
            }
        }

        //Порівняння дробів
        private void btnGetComparison_Click(object sender, EventArgs e)
        {
            if(f2 is null)
            {
                f2 = new Fractions();
            }
            lblFirstFraction.Text = f1.ToString();
            lblSecondFraction.Text = f2.ToString();
            bool equal, noEqual, greater, less, greaterEqual, lessEqual;
            equal = f1 == f2;
            noEqual = f1 != f2;
            greater = f1 > f2;
            less = f1 < f2;
            greaterEqual = f1 >= f2;
            lessEqual = f1 <= f2;
            lblIsEqual.Text = equal.ToString();
            lblIsNoEqual.Text = noEqual.ToString();
            lblIsGreater.Text = greater.ToString();
            lblIsLess.Text = less.ToString();
            lblIsGreaterEqual.Text = greaterEqual.ToString();
            lblIsLessEqual.Text = lessEqual.ToString();
        }

        //Арифметичні операції
        private void btnResult_Click(object sender, EventArgs e)
        {
            try
            {
                lblExceptionOutput.Text = "";
                int n = Convert.ToInt32(txtPowNumber.Text);
                if (n == 0)
                {
                    throw new ArgumentException("Степінь має бути натуральним");
                }
                if (f2 is null)
                {
                    f2 = new Fractions();
                }
                lblOperationFirstFraction.Text = f1.ToString();
                lblOperationSecondFraction.Text = f2.ToString();
                Fractions sum, sub, mul, div, pow;
                sum = f1 + f2;
                sum.Simplify();
                sub = f1 - f2;
                sub.Simplify();
                mul = f1 * f2;
                mul.Simplify();
                div = f1 / f2;
                div.Simplify();
                pow = f2.Pow(n);
                pow.Simplify();
                lblSumResult.Text = sum.ToString();
                lblSepResult.Text = sub.ToString();
                lblMulResult.Text = mul.ToString();
                lblDivResult.Text = div.ToString();
                lblPowResult.Text = pow.ToString();
            }
            catch(ArgumentException ex)
            {
                lblExceptionOutput.Text = ex.Message;
            }
            catch(DivideByZeroException ex)
            {
                lblExceptionOutput.Text = ex.Message;
            }
            catch
            {
                txtPowNumber.Focus();
            }
        }
    }
}