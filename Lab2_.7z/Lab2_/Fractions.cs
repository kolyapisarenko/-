﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_
{
    internal class Fractions
    {
        int numerator;
        int denominator;
        public int Numerator
        {
            get { return numerator; }
            set { numerator = value; }
        }
        public int Denominator
        {
            get { return denominator; }
            set
            { denominator = value; }
        }
        public Fractions()
        {
            Numerator = 1;
            Denominator = 2;
        }
        public Fractions(int n, int d)
        {
            if (d == 0)
            {
                throw new ArgumentException("Знаменник не може дорівнювати 0!");
            }
            else if (d < 0)
            {
                throw new ArgumentException("Знаменник має бути натуральним числом");
            }
            else
            {
                Numerator = n;
                Denominator = d;
                Simplify();
            }
        }
        public Fractions(Fractions other)
        {
            this.numerator = other.numerator;
            this.denominator = other.denominator;
        }
        ~Fractions() { }
        public override string ToString()
        {
            if (Numerator == Denominator)
            {
                return "1";
            }
            else if(Numerator % Denominator == 0)
            {
                int num = Numerator / Denominator;
                return num.ToString();
            }
            else if (Numerator == 0)
            {
                return "0";
            }
            else
            {
                return Numerator + "/" + Denominator;
            }
        }
        public static Fractions operator +(Fractions f1, Fractions f2)
        {
            int newDenominator = f1.Denominator * f2.Denominator;
            int newNumerator = (f1.Numerator * f2.Denominator) + (f2.Numerator * f1.Denominator);
            return new Fractions(newNumerator, newDenominator);
        }
        public static Fractions operator -(Fractions f1, Fractions f2)
        {
            int newDenominator = f1.Denominator * f2.Denominator;
            int newNumerator = (f1.Numerator * f2.Denominator) - (f2.Numerator * f1.Denominator);
            return new Fractions(newNumerator, newDenominator);
        }
        public static Fractions operator *(Fractions f1, Fractions f2)
        {
            int newDenominator = f1.Denominator * f2.Denominator;
            int newNumerator = f1.Numerator * f2.Numerator;
            return new Fractions(newNumerator, newDenominator);
        }
        public static Fractions operator /(Fractions f1, Fractions f2)
        {
            if (f2.Numerator == 0)
            {
                throw new DivideByZeroException("Ділення на 0!");
            }
            int newDenominator = f1.Denominator * f2.Numerator;
            int newNumerator = f1.Numerator * f2.Denominator;
            if (newDenominator < 0)
            {
                newDenominator = -newDenominator;
                newNumerator = -newNumerator;
            }
            return new Fractions(newNumerator, newDenominator);
        }
        private int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        public void Simplify()
        {
            int gcd = GCD(Math.Abs(numerator), Math.Abs(denominator));
            numerator /= gcd;
            denominator /= gcd;
        }
        public Fractions Pow(int n)
        {
            int newDenominator = (int)Math.Pow(Denominator, n);
            int newNumerator = (int)Math.Pow(Numerator, n);
            return new Fractions(newNumerator, newDenominator);
        }
        public static bool operator ==(Fractions f1, Fractions f2)
        {
            double a, b;
            a = (double)f1.Numerator / f1.Denominator;
            b = (double)f2.Numerator / f2.Denominator;
            return a == b;
        }
        public static bool operator !=(Fractions a, Fractions b)
        {
            double f1, f2;
            f1 = (double)a.Numerator / a.Denominator;
            f2 = (double)b.Numerator / b.Denominator;
            return f1 != f2;
        }
        public static bool operator >=(Fractions a, Fractions b)
        {
            double f1, f2;
            f1 = (double)a.Numerator / a.Denominator;
            f2 = (double)b.Numerator / b.Denominator;
            return f1 >= f2;
        }
        public static bool operator <=(Fractions a, Fractions b)
        {
            double f1, f2;
            f1 = (double)a.Numerator / a.Denominator;
            f2 = (double)b.Numerator / b.Denominator;
            return f1 <= f2;
        }
        public static bool operator >(Fractions a, Fractions b)
        {
            double f1, f2;
            f1 = (double)a.Numerator / a.Denominator;
            f2 = (double)b.Numerator / b.Denominator;
            return f1 > f2;
        }
        public static bool operator <(Fractions a, Fractions b)
        {
            double f1, f2;
            f1 = (double)a.Numerator / a.Denominator;
            f2 = (double)b.Numerator / b.Denominator;
            return f1 < f2;
        }
        public void SetNumerator(int n)
        {
            Numerator = n;
        }
        public void SetDenominator(int d)
        {
            if (d == 0)
            {
                throw new ArgumentException("Знаменник повинен бути більший за 0");
            }
            else
            {
                Denominator = d;
            }
        }
    }
}